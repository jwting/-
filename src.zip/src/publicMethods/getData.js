var getData = function (Vue) {
  Vue.prototype.getData = function (url,repName,resName,isMsg=true) {
    var that = this;
    this.axios({
      method: 'post',
      data:repName,
      url: url,
    }).then(function (res) {
      if(res.data.status==200){
        that[resName] = res.data;
        if(isMsg){
          that.$message({
            message: res.data.msg,
            type: 'success'
          });
        }
      }else {
        if(isMsg){
          that.$message.error(res.data.msg);
        }
      }
    })
  }
};

export default {
  install:getData
}
