<template>
    <div>
      <div class="click" v-for="(v,i) of data">
       <div>
         <span @click="openChecked(v.id)" :class="isChecked.indexOf(v.id)==-1?'el-icon-arrow-right':'el-icon-arrow-down'"></span>
         <el-checkbox v-model="v.status" :indeterminate="v.isIndeterminate" @change="parseChange(v.status,v.children,i)" ></el-checkbox>
         <span @click="openChecked(v.id)">&nbsp;{{v.permissionName}}</span>
       </div>
          <div>
            <div v-for="item of v.children" v-if="isChecked.indexOf(v.id)!=-1">
              <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
              <el-checkbox v-model="item.status" @change="childChange(v.children,i)"></el-checkbox>
              <span>&nbsp;{{item.permissionName}}</span>
            </div>
          </div>
      </div>
    </div>
</template>

<script>
    export default {
      name: "permissionTree",
      props:["treeData"],
      data(){
        return{
          checked:false,
          isChecked:[],
          data: this.treeData
        }
      },
      watch:{
        data:{
          handler (cval, oval) {
            this.$emit('change',cval)
          },
          deep: true
        },
        treeData:{
          handler(){
            this.data = this.treeData
          }
        }
      },
      methods:{
        openChecked:function (id) {
          if(this.isChecked.indexOf(id)==-1){
            this.isChecked.push(id);
          }else {
            const index = this.isChecked.indexOf(id);
            this.isChecked.splice(index,1);
          }
        },
        parseChange:function (status,children,i) {
          for (var v of children){
            v.status = status;
          }
          this.data[i].isIndeterminate = false;
        },
        childChange:function (children,i) {
          var length = children.length;
          var islen = 0;
          for (var v of children){
            if(v.status){
              islen++;
            }
          }
          if(islen==length){
            this.data[i].status = true;
            this.data[i].isIndeterminate = false;
          }else if(islen==0){
            this.data[i].status = false;
          }else if(islen!=0){
            this.data[i].status = false;
            this.data[i].isIndeterminate = true;
          }
        }
      }
    }
</script>

<style scoped>
  .click{
    cursor: pointer;
  }
</style>
