<template>
  <div class="action_tit">
    <div class="left left-padding">
      <span class="weight min-size">
        <i class="fa fa-th"></i><span>&nbsp;</span>{{title}}</span>
    </div>
    <div class="tit-nav navigation">
      <div @mouseenter="userNav=true" class="bottom" @mouseleave="userNav=false">
        <span class="tit_text min-size">
          <i class="fa fa-user"></i>
          <span>&nbsp;</span>
          {{getUser.deptName}}<span>&nbsp;-&nbsp;</span>{{getUser.userName}}
        </span>
        <span>&nbsp;&nbsp;&nbsp;</span>
        <i class="fa fa-user-circle-o icon-size"></i>
        <div v-show="userNav" class="userNav min-size">
          <router-link
            v-for="(v,i) in toPagenData"
            class="left li"
            :key="i"
            :class="{selectCss:v.isSelect}"
            :to="{ name: v.name, params: { value: v.value }}">
            <div @mouseenter="v.isSelect=true" @mouseleave="v.isSelect=false">
              <i class="type-face" :class="v.icon"></i>
              <span class="min-size">&nbsp;{{v.title}}</span>
            </div>
          </router-link>
        </div>
      </div>
    </div>
    <div class="tit-integral navigation">
      <span class="min-size">
          <i class="fa fa-gg-circle"></i>
          <span>&nbsp;</span>
          {{' 当前积分：'+getUser.integral}}
      </span>
    </div>
  </div>
</template>

<script>
    import mixinsMethon from './mixins-methon.js'
    export default {
      mixins:[mixinsMethon],
    }
</script>

<style scoped>
  .navigation{
    transition: .2s;
    cursor: pointer;
  }
  .navigation:hover{
    background: #EBEEF5;
  }
  .li:hover{
     background:#F2F6FC;
  }
  .icon-size{
    font-size: 30px;
    vertical-align: middle;
  }
  .type-face{
    display:inline-block;
    width:20%;
    color: #909399;
    text-align: center
  }
  .action_tit{
    position: fixed;
    left: 180px;
    top: 0;
    width: 100%;
    height: 60px;
    background: #fff;
    z-index: 999;
    padding-right: 195px;
    line-height: 60px;
    margin-bottom: 5px;
    box-shadow:6px 1px 3px 0px #ccc;
    color: #606266;
  }
  .timg{
    width: 35px;
    height: 35px;
    border-radius: 50%;
    margin-top: 16px;
    display: inline-block;
    background: #409EFF;
  }
  .weight{
    font-weight: 600;
    color: #000
  }
  .li{
    height: 40px;
    line-height: 40px;
    border-radius: 5px;
    color: #4b4b4b;
    display: block;
  }
  .tit-integral{
    float: right;
    text-align: right;
    padding: 0 20px;
    border-right: 1px solid #EBEEF5; 
  }
  .titbtn{
    cursor: pointer;
    height: 75px;
    line-height: 75px;
    text-align: right;
  }
  .tit_text{
    vertical-align: middle;
  }
  .size{
    font-size: 15px;
    color: #4d4d4d;
  }
  .left-padding{
    padding-left: 50px;
    width: 200px;
    float: left
  }
  .userNav{
    position: absolute;
    width: 150px;
    height: auto;
    background: #fff;
    right: 0px;
    top: 60px;
    border-radius: 5px;
    box-shadow: 5px 5px 10px #dedede;
    padding: 10px 20px;
    z-index: 999;
  }
  .bottom{
    position: relative;
    line-height: 60px;
  }
  .tit-nav{
    height: 60px;
    padding: 0 20px;
    float: right;
    text-align: right;
  }
</style>
