<template>
  <div class="action_child" style="background: none;padding: 0">
    <action_tit title="规则筛选"></action_tit>
    <div class="childApp" style="margin-bottom: 10px;min-height: 0">
      <el-row class="tit">
        <el-col :span="10">
          <div class="is-dq el-icon-view">
            <span>当前已选择</span>
            <span class="nub">{{data.queryField.length}}</span>
            <span>个条件</span>
          </div>
        </el-col>
      </el-row>
      <!--字段间逻辑-->
      <el-row class="strate row-height" :gutter="15">
        <el-col class="x" :span="3" style="padding-left: 15px">满足下列：</el-col>
        <el-col :span="3">
          <el-select class="input" v-model="data.logicValue" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
        </el-col>
        <el-col class="x" :span="2">&nbsp;&nbsp;&nbsp;条件</el-col>
        <el-col :span="8">
          <el-alert
            title="请选择字段间逻辑"
            type="error"
            class="w"
            :closable="false"
            show-icon
            v-show="tiArr[0]"
          ></el-alert>
        </el-col>
      </el-row>

      <!--条件列表-->
      <el-row class="strate" :gutter="15" :key="k" v-for="(v,k) in data.queryField">
        <el-col :span="3" :offset="3">
          <el-select v-model="data.queryField[k].field" @change="change(k)" placeholder="添加筛选字段">
            <el-option
              v-for="item in conditions"
              :key="item.field"
              :label="item.field"
              :value="item.field"
              :disabled="queryIsString.indexOf(item.field)!=-1"
            ></el-option>
          </el-select>
        </el-col>

        <!--字段提交提示信息-->
        <el-alert
          title="当前字段未填写完整"
          type="error"
          class="field-ti"
          :closable="false"
          show-icon
          v-show="data.queryField[k].ischild"
        ></el-alert>
        <!--范围判断提示信息-->
        <el-alert
          v-show="data.queryField[k].isFile"
          title="提示！当前范围值搜索到的内容为空"
          type="warning"
          class="um-field-ti"
          :closable="false"
          show-icon
        ></el-alert>

        <!--是否型-->
        <el-col :span="3" v-show="data.queryField[k].field!=''">
          <el-select
            v-if="(data.queryField[k].type==3)"
            v-model="data.queryField[k].conditions"
            placeholder="选择逻辑关系"
          >
            <el-option
              v-for="item in isfOption"
              :key="item.value"
              :label="item.label"
              style="color: #000"
              :value="item.value"
            ></el-option>
          </el-select>
          <!--文本型-->
          <el-select
            v-if="(data.queryField[k].type==1)"
            v-model="data.queryField[k].fieldLogic"
            placeholder="选择逻辑关系"
          >
            <el-option
              v-for="item in isTextOption"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
          <!--数值型-->
          <el-select
            v-if="(data.queryField[k].type==2)"
            @change="numberChange(k)"
            v-model="data.queryField[k].fieldLogic"
            placeholder="选择逻辑关系"
          >
            <el-option
              v-for="item in isNumberOption"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            ></el-option>
          </el-select>
          <!--地区-->
          <template v-if="data.queryField[k].type==4">
            <el-cascader
              v-model="(typeof data.queryField[k].conditions=='string')?arr:data.queryField[k].conditions"
              v-if="data.queryField[k].type==4"
              :options="provincesOptions"
              @change="handleItemChange(k)"
              style="color: #000"
              :props="props"
            ></el-cascader>
          </template>
        </el-col>
        <!--范围值渲染-->
        <template
          v-if="data.queryField[k].type!=4"
          v-for="(textItem,textIdenx) in ((data.queryField[k].type==1&&data.queryField[k].conditions!='')||(data.queryField[k].type==2)?data.queryField[k].conditions.split(','):[])"
        >
          <el-col
            :span="3"
            :style="data.queryField[k].conditions.split(',').length>3?'margin-bottom: 10px':''"
            :offset="((data.queryField[k].type==1&&(textIdenx==4||textIdenx==8))||
                    (data.queryField[k].type==2&&(textIdenx==3||textIdenx==6)))?9:0"
          >
            <!--文本范围渲染-->
            <el-input
              class="scinput"
              v-show="data.queryField[k].type==1&&textItem!=''"
              :value="textItem"
              :readonly="true"
            >
              <el-button
                slot="append"
                class="delect-close"
                @click="deleteTextItem(k,textIdenx)"
                icon="el-icon-close"
              ></el-button>
            </el-input>
            <!--数值未选择-->
            <div
              v-show="data.queryField[k].type==2&&textItem==''"
              @click="insertNumber(k,textIdenx,$event)"
            >
              <el-input class="scinput" :readonly="true" placeholder="未选择">
                <el-button
                  slot="append"
                  class="delect-close"
                  @click="deleteTextItem(k,textIdenx)"
                  icon="el-icon-close"
                ></el-button>
              </el-input>
            </div>
            <!--非and-->
            <div
              v-show="data.queryField[k].type==2&&textItem.search(/and/)==-1&&textItem!=''"
              @click="insertNumber(k,textIdenx,$event)"
            >
              <el-input class="scinput" :value="textItem+data.queryField[k].unit" :readonly="true">
                <el-button
                  slot="append"
                  class="delect-close"
                  @click="deleteTextItem(k,textIdenx)"
                  icon="el-icon-close"
                ></el-button>
              </el-input>
            </div>
            <!--and-->
            <div
              @click="insertNumber(k,textIdenx,$event)"
              v-show="data.queryField[k].type==2&&textItem.search(/and/)!=-1"
            >
              <el-input
                class="scinput"
                :value="'介于:'+textItem.split('and')[0]+data.queryField[k].unit+'至'+textItem.split('and')[1]+data.queryField[k].unit"
                :readonly="true"
                placeholder="未选择"
              >
                <el-button
                  slot="append"
                  class="delect-close"
                  @click="deleteTextItem(k,textIdenx)"
                  icon="el-icon-close"
                ></el-button>
              </el-input>
            </div>
          </el-col>
          <el-col
            v-show="data.queryField[k].type==2&&data.queryField[k].conditions.split(',').length>1&&textIdenx!=data.queryField[k].conditions.split(',').length-1"
            :span="1"
          >
            <el-input class="scinput" :value="data.queryField[k].fieldLogic==1?'且':'或'"></el-input>
          </el-col>
        </template>

        <!--添加数值弹窗-->
        <el-dialog
          title="添加范围"
          :visible.sync="dialogVisible"
          width="45%"
          :before-close="handleClose"
          center
        >
          <el-row class="push-row" type="flex" justify="center">
            <el-col class="top" :span="4">
              <div>请输入范围：</div>
            </el-col>
            <el-col class="top" :span="5">
              <el-select style="float: left" v-model="isNumber.logic" placeholder="选择条件">
                <el-option
                  v-for="item in isNumberLogic"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                ></el-option>
              </el-select>
            </el-col>
            <el-col :span="8">
              <el-input
                style="float: left"
                v-model="isNumber.number"
                v-show="isNumber.logic!='and'&&isNumber.logic!=''"
              >
                <template slot="append">{{isNumber.unit?isNumber.unit:''}}</template>
              </el-input>
              <div v-show="isNumber.logic=='and'" class="center">
                <el-input v-model="isNumber.number" style="width: 40%;float: left">
                  <template slot="append">{{isNumber.unit?isNumber.unit:''}}</template>
                </el-input>
                <span style="width: 20%;float: left">至</span>
                <el-input v-model="isNumber.maxNumber" style="width: 40%;float: left">
                  <template slot="append">{{isNumber.unit?isNumber.unit:''}}</template>
                </el-input>
              </div>
            </el-col>
          </el-row>
          <el-row class="push-row" type="flex" justify="center" v-show="isNumber.isti">
            <el-col :span="18">
              <div style="color: #eb0000">{{isNumber.tiText}}</div>
            </el-col>
          </el-row>
          <span slot="footer" class="dialog-footer">
            <el-button @click="dialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="preservation">确 定</el-button>
          </span>
        </el-dialog>

        <!--添加范围-->
        <el-col v-if="data.queryField[k].type!=4" :span="1" class="push-range">
          <div
            v-show="data.queryField[k].fieldLogic!=''&&data.queryField[k].type!=3&&data.queryField[k].type!=''&&data.queryField[k].conditions.split(',').length<7"
            @click="pushRange(k)"
          >
            <i style="color:#409EFF" class="el-icon-circle-plus-outline"></i>
          </div>
        </el-col>

        <!--删除当前字段-->
        <div class="delete-field">
          <el-popover placement="top" width="160" v-model="data.queryField[k].visible">
            <p class="el-icon-info" style="margin-bottom: 10px">是否删除当前字段</p>
            <div style="text-align: right; margin: 0">
              <el-button size="mini" type="text" @click="data.queryField[k].visible = false">取消</el-button>
              <el-button type="primary" size="mini" @click="deleteField(k)">确定</el-button>
            </div>
            <div slot="reference">
              <i style="color: #F56C6C" class="el-icon-delete loc"></i>
            </div>
          </el-popover>
        </div>
      </el-row>

      <!--添加字段-->
      <el-row class="strate" :gutter="15">
        <el-col :span="3" :offset="3">
          <el-button class="btn" @click="pushQuery" type="primary" plain icon="el-icon-plus">添加条件</el-button>
        </el-col>
        <el-col :span="8">
          <el-alert
            title="请添加条件"
            type="error"
            class="w"
            :closable="false"
            show-icon
            v-show="tiArr[1]"
          ></el-alert>
        </el-col>
      </el-row>

      <!--筛选与保存-->
      <el-row class="strate" :gutter="15">
        <el-col :span="3">
          <el-input v-model="data.strategyName" placeholder="策略名称"></el-input>
        </el-col>
        <el-col :span="3">
          <el-button
            class="btn"
            :disabled="isbtn"
            type="primary"
            :loading="isbtn"
            @click="pushSubmit"
            icon="el-icon-refresh"
          >开始筛选</el-button>
        </el-col>
        <el-col :span="2">
          <el-button
            class="btn"
            :disabled="isbtn"
            type="danger"
            @click="clearList"
            icon="el-icon-delete"
          >清空列表</el-button>
        </el-col>
        <el-col :span="5" :offset="1">
          <el-alert
            title="请填写策略名称"
            type="error"
            class="w"
            :closable="false"
            show-icon
            v-show="tiArr[2]"
          ></el-alert>
        </el-col>
        <el-button @click="push" style="position: absolute;right: 10px">历史策略</el-button>
      </el-row>
      <!--进度条-->
      <progress-bar @closeChange="searchClose" :is-display="isbtn"></progress-bar>
    </div>

    <!--提示宽-->
    <el-dialog title="提示" :visible.sync="dialogSelect" width="35%">
      <span>{{selectDate}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogSelect = false">取 消</el-button>
        <el-button type="primary" @click="getSelect">确 定</el-button>
      </span>
    </el-dialog>
    <div class="childApp" style="padding-bottom: 20px">
      <div class="row-btn">
        <div class="float-left width">
          <span v-show="resData.countSum" class="el-icon-success" style="color:#409EFF"></span>
          <span>&nbsp;百邑为您筛选出</span>
          <span class="red">{{resData.countSum}}</span>
          <span>条销售线索</span>
          <el-button type='danger' icon="fa fa-hourglass-end" size='mini' @click="handleClickClueAll" class="unallocated-cue" >&nbsp;&nbsp;{{isClueAll}}</el-button>
        </div>
        <div class="float-right width">
          <el-button
            :disabled="selectAll!=''"
            :loading="selectAll=='查看选中'"
            @click="handleCommand(1)"
            type="primary"
          >选中进入线索池</el-button>
          <el-button
            :disabled="selectAll!=''"
            :loading="selectAll=='导出选中'"
            @click="handleCommand(2)"
            plain
            type="primary"
          >导出选中</el-button>
          <el-button
            :disabled="selectAll!=''"
            :loading="selectAll=='查看全部'"
            @click="handleCommand(3)"
            type="primary"
          >全部进入线索池</el-button>
          <el-button
            :disabled="selectAll!=''"
            :loading="selectAll=='导出全部'"
            @click="handleCommand(4)"
            plain
            type="primary"
          >导出全部</el-button>
        </div>
      </div>

      <!--筛选结果标题-->
      <el-row class="tit-row">
        <el-col :span="1" class="center">
          <el-checkbox :disabled="!resData.data" @change="pubilkChange" v-model="checked"></el-checkbox>
        </el-col>
        <el-col :span="5" class="left">企业名称</el-col>
        <el-col :span="4" class="center">官网</el-col>
        <el-col :span="5" class="center">地址</el-col>
        <el-col :span="6" class="center">主营产品</el-col>
        <el-col :span="3" class="right pad">注册日期</el-col>
      </el-row>

      <!--进度条-->
      <progress-bar @closeChange="handleCloseChange" :is-display="progress"></progress-bar>

      <!--筛选结果列表-->
      <el-row v-for="v in resData.data" class="act-row" :key="v.id">
        <el-col :span="1" class="center">
          <el-checkbox @change="reChange" v-model="v.is"></el-checkbox>
        </el-col>
        <el-col style="cursor: pointer" :span="5" class="left color">
          <el-popover placement="top" width="300" trigger="hover">
            <div class="center pad font-popover">公司名称</div>
            <div class="center pad" style="margin-bottom: 6px">{{v.companyName}}</div>
            <div slot="reference">
              <span>{{v.companyName}}</span>
            </div>
          </el-popover>
        </el-col>
        <el-col :span="4" class="center pad">
          <a
            :href="v.webSite.toString().indexOf('http')!=-1?v.webSite:'http://'+v.webSite"
            class="color"
            target="_blank"
          >{{v.webSite?v.webSite:"/"}}</a>
        </el-col>
        <el-col style="cursor: pointer" :span="5" class="center pad">
          <el-popover placement="top" width="300" trigger="hover">
            <div class="center pad font-popover">地址</div>
            <div class="center pad" style="margin-bottom: 6px">{{v.address}}</div>
            <div slot="reference">
              <span>{{v.address?v.address:'&nbsp;'}}</span>
            </div>
          </el-popover>
        </el-col>
        <el-col style="cursor: pointer" :span="6" class="center pad">
          <el-popover placement="top" width="300" trigger="hover">
            <div class="center pad font-popover">主营产品</div>
            <div class="center pad" style="margin-bottom: 6px">{{v.operation}}</div>
            <div slot="reference">
              <span>{{v.operation?v.operation:'&nbsp;'}}</span>
            </div>
          </el-popover>
        </el-col>
        <el-col :span="3" class="right pad">{{v.createTime}}</el-col>
      </el-row>

      <div v-show="resData.countSum" style="text-align: center;margin-top: 20px">
        <el-button
          :loading="islod"
          style="background: #fff;border: none;color: #7a7a7a"
        >{{islod?"努力加载中":lodText}}</el-button>
      </div>

      <div
        v-if="!resData.countSum&&!isbtn"
        style="text-align: center;line-height: 50px;height: 50px;margin-top: 60px"
      >
        <img
          style="width: 50px;height: 50px;vertical-align: middle"
          src="https://shop.bybigdata.com/image/提示.png"
        >
        <span>&nbsp;&nbsp;</span>
        <span
          style="vertical-align: middle;font-weight: 600;color: #b9b9b9"
        >{{resData.countSum==0?"请输入合理的筛选条件哦！":"请输入条件筛选哦！"}}</span>
      </div>
    </div>
  </div>
</template>

<script>
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import progressBar from "@/components/progressBar/progressBar.vue";
export default {
  name: "screening",
  components: { Action_tit, progressBar },
  data() {
    return {
      progress: false,
      isPopup: false,
      toSelectNumber: 0,
      isSelectAll: false,
      selectAll: "",
      dialogSelect: false,
      isbtn: false,
      lodText: "滑动滚轮查看更多",
      islod: false,
      conditionData: {},
      //前端自带数据
      arr: [],
      provincesOptions: [],
      provinces: "",
      props: {
        value: "provinceName",
        children: "citys",
        label: "provinceName"
      },
      isNumberLogic: [
        {
          value: ">",
          label: ">"
        },
        {
          value: "<",
          label: "<"
        },
        {
          value: ">=",
          label: ">="
        },
        {
          value: "<=",
          label: "<="
        },
        {
          value: "=",
          label: "="
        },
        {
          value: "!=",
          label: "不等于"
        },
        {
          value: "and",
          label: "介于"
        }
      ],
      //字段间逻辑
      options: [
        {
          value: "2",
          label: "符合其中一个"
        },
        {
          value: "1",
          label: "符合所有"
        }
      ],
      //数值型
      isNumberOption: [
        {
          value: "1",
          label: "符合所有"
        },
        {
          value: "2",
          label: "符合其中一个"
        }
      ],
      //文本型
      isTextOption: [
        {
          value: "1",
          label: "符合所有"
        },
        {
          value: "2",
          label: "符合其中一个"
        },
        {
          value: "3",
          label: "符合全部才排除"
        },
        {
          value: "4",
          label: "符合一个就排除"
        }
      ],
      //是否型
      isfOption: [
        {
          value: "1",
          label: "是"
        },
        {
          value: "0",
          label: "否"
        }
      ],
      //后端返回数据
      //返回字段
      conditions: [],
      //返回筛选结果
      countSum: 10000,
      resData: {},
      selectDate: {},
      //样式控制
      checked: false,
      dialogVisible: false,
      loading: false,
      //上传前待处理数据
      queryFieldName: "",
      //地区选择器所在上传数据index
      k: "",
      queryIsString: "",
      isNumber: {
        k: "",
        i: "",
        unit: "",
        logic: "",
        number: "",
        maxNumber: "",
        isti: false,
        tiText: ""
      },
      visible2: false,
      isfilde: "",
      isPlac: true,
      isTrue: true,
      isFalse: false,
      textArr: ["信息", "科技"],
      tiArr: [false, false, false],
      command: "",
      //需上传数据
      data: {
        isDistinct: 0,
        //字段间逻辑
        logicValue: "1",
        userId: "用户ID",
        //策略名称
        strategyName: "",
        //页码
        pageNumber: "1",
        //每页展示的条数
        rows: "20",
        queryField: [],
        hId:""
      },
      //查看联系方式上传的数据
      seeEnterprise: {
        lists: [], //公司ID集合  逗号分隔
        userId: "", //用户ID
        type: 0, //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
        hId: "",   //历史策略ID
        isDistinct: 0,
        isTrue: 0
      },
      //导出联系方式
      exportlist: {
        lists: [],
        hId: "", //历史策略ID
        isDistinct: 0,
        userId: 1, //用户ID
        isTrue: 0, //0：查看需要消耗积分  1：导出
        type: 3
      },
      selectNumberInterval: "",
      isErr: ""
    };
  },
  computed: {
    isClueAll(){
      var text = this.data.isDistinct == 0 ? '过滤已被加入的线索' : '查看全部线索'
      return text
    }
  },
  methods: {
    handleClickClueAll(){
      const val = this.data.isDistinct == 0 ? 1 : 0
      this.data.isDistinct = val
      //如果过滤已选公司 发送策略ID
      this.data.hId = window.localStorage["hId"];

      this.pushClueSubmit();
    },
    searchClose: function() {
      this.$message({
        type: "success",
        message: "百邑为您筛选出: " + this.resData.countSum + "条数据"
      });
    },
    //进度条结束
    handleCloseChange: function() {
      if (this.isPopup && !this.isErr) {
        this.dialogSelect = true;
      }
    },
    //清空列表
    clearList: function() {
      this.$confirm("是否清空筛选列表", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.data.queryField = [];
          this.forField();
        })
        .catch(() => {});
    },
    //用户选择省市
    handleItemChange: function(k) {},
    //调转历史策略
    push: function() {
      this.$router.push({ name: "Historical", params: { value: "0" } });
    },
    // 查看与导出联系方式
    getSelect: function() {
      var that = this;
      this.dialogSelect = false;
      this.isPopup = false;
      if (that.command == 1) {
        this.progress = true;
        that.seeEnterprise.hId = window.localStorage["hId"];
        that.seeEnterprise.isDistinct = this.data.isDistinct;
        that.seeEnterprise.isTrue = 1;
        that.selectAll = "查看选中";
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/showCompanyPhone",
            data: that.seeEnterprise
          })
          .then(function(res) {
            that.isRespons(res.data.status, false, res.data.data);
            that.$message({
              type: "success",
              message: res.data.msg
            });
          })
          .catch(function(error) {
            that.selectAll = "";
            that.progress = false;
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      } else if (that.command == 2) {
        this.progress = true;
        that.exportlist.isTrue = 1;
        that.exportlist.isDistinct = this.data.isDistinct;
        that.exportlist.hId = window.localStorage["hId"];
        that.selectAll = "导出选中";
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/exportCompanyInfo",
            data: that.exportlist
          })
          .then(function(res) {
            that.isRespons(res.data.status, false, res.data.data);
            that.urlDownload(res.data.data.FileUrl);
            that.$message({
              type: "success",
              message: res.data.msg
            });
          })
          .catch(function(error) {
            that.selectAll = "";
            that.progress = false;
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      } else if (that.command == 4) {
        this.progress = true;
        var ids = that.getUpdataId(that.resData.data, "ids");
        that.selectAll = "导出全部";
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/exportAllCompanyInfo",
            data: {
              query: that.conditionData,
              isTrue: 1, //0：查看需要消耗积分  1：导出
              ids: ids,
              type: 3
            }
          })
          .then(function(res) {
            that.isRespons(res.data.status, false, res.data.data);
            that.urlDownload(res.data.data.FileUrl);
            that.$message({
              type: "success",
              message: res.data.msg
            });
          })
          .catch(function(error) {
            that.selectAll = "";
            that.progress = false;
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      } else if (that.command == 3) {
        this.progress = true;
        var ids = that.getUpdataId(that.resData.data, "ids");
        that.selectAll = "查看全部";
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/showCompanyAllPhone",
            data: {
              query: that.conditionData,
              isTrue: 1, //0：查看需要消耗积分  1：导出
              ids: ids, //公司ID集合  逗号分隔
              type: 1 //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
            }
          })
          .then(function(res) {
            that.isRespons(res.data.status, false, res.data.data);
            that.$message({
              type: "success",
              message: res.data.msg
            });
          })
          .catch(function(error) {
            that.selectAll = "";
            that.progress = false;
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      }
    },
    //判断积分不足
    LackOfIntegral: function(status) {},
    //接收请求参数后
    isRespons: function(status, is, data) {
      if (status == 200) {
        this.isErr = false;
        this.selectAll = "";
      } else if (status == 405 && !is) {
        this.isErr = true;
        this.selectAll = "";
        this.$confirm("积分不足，请联系客服充值", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {})
          .catch(() => {});
      } else {
        this.isErr = true;
        this.selectAll = "";
        this.$message.error("请求错误");
      }
      this.progress = false;
    },
    //查看积分消耗
    handleCommand: function(command) {
      var that = this;
      that.command = command;
      this.isPopup = true;
      if (command == 1) {
        that.seeEnterprise.lists = that.getUpdataId(that.resData.data, "lists");
        if (this.seeEnterprise.lists.length == 0) {
          that.$message({
            type: "warning",
            message: "请选择需查看企业"
          });
          return;
        }
        that.seeEnterprise.hId = window.localStorage["hId"];
        that.seeEnterprise.isDistinct = this.data.isDistinct;
        that.seeEnterprise.isTrue = 0;
        that.selectAll = "查看选中";
        this.progress = true;
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/showCompanyPhone",
            data: that.seeEnterprise
          })
          .then(function(res) {
            that.isRespons(res.data.status, true);
            that.selectDate = res.data.data.Consumption;
          })
          .catch(function(error) {
            that.progress = false;
            that.selectAll = "";
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      } else if (command == 2) {
        that.exportlist.hId = window.localStorage["hId"];
        that.exportlist.isDistinct = this.data.isDistinct;
        that.exportlist.lists = that.getUpdataId(that.resData.data, "lists");
        that.exportlist.isTrue = 0;
        if (that.exportlist.lists.length == 0) {
          that.$message({
            type: "warning",
            message: "请选择需导出的企业"
          });
          return;
        }
        that.selectAll = "导出选中";
        this.progress = true;
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/exportCompanyInfo",
            data: that.exportlist
          })
          .then(function(res) {
            that.isRespons(res.data.status, true);
            that.selectDate = res.data.data.Consumption;
          })
          .catch(function(error) {
            that.selectAll = "";
            that.isSelectAll = false;
            that.progress = false;
            that.$message.error("请求错误");
          });
      } else if (command == 4) {
        var ids = that.getUpdataId(that.resData.data, "ids");
        if (!ids) {
          that.$message({
            type: "warning",
            message: "无线索！"
          });
          return;
        }
        that.selectAll = "导出全部";
        this.progress = true;
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/exportAllCompanyInfo",
            data: {
              query: that.conditionData,
              ids: ids,
              isTrue: 0 //0：查看需要消耗积分  1：导出
            }
          })
          .then(function(res) {
            that.isRespons(res.data.status, true);
            that.selectDate = res.data.data.Consumption;
          })
          .catch(function(error) {
            that.selectAll = "";
            that.progress = false;
            that.isSelectAll = false;
            that.$message.error("请求错误");
          });
      } else if (command == 3) {
        var ids = that.getUpdataId(that.resData.data, "ids");
        if (!ids) {
          that.$message({
            type: "warning",
            message: "无线索！"
          });
          return;
        }
        that.selectAll = "查看全部";
        this.progress = true;
        that
          .axios({
            method: "post",
            url: that.host + "companyInfo/showCompanyAllPhone",
            data: {
              query: that.conditionData,
              isTrue: 0, //0：查看需要消耗积分  1：导出
              ids: ids, //公司ID集合  逗号分隔
              type: 0 //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
            }
          })
          .then(function(res) {
            that.isRespons(res.data.status, true);
            that.selectDate = res.data.data.Consumption;
          })
          .catch(function(error) {
            that.selectAll = "";
            that.isSelectAll = false;
            that.progress = false;
            that.$message.error("请求错误");
          });
      }
    },
    //导出联系方式
    exportHandleCommand: function() {},
    //单选
    reChange: function(e) {},
    //全选
    pubilkChange: function(e) {
      for (var v of this.resData.data) {
        v.is = e;
      }
    },
    //开始筛选
    pushSubmit: function() {
      var isSubmit = 0;
      this.tiArr = [false, false, false];
      //字段间逻辑为空
      if (this.data.logicValue == "") {
        this.tiArr[0] = true;
        isSubmit++;
      }
      //未添加字段
      if (this.data.queryField.length == 0) {
        this.tiArr[1] = true;
        isSubmit++;
      }
      if (this.data.strategyName == "") {
        this.tiArr[2] = true;
        isSubmit++;
      }
      for (var v of this.data.queryField) {
        v.ischild = false;
        if (
          (v.fieldLogic == "" || v.field == "") &&
          v.type != 4 &&
          v.type != 3
        ) {
          v.ischild = true;
          isSubmit++;
        } else if (v.type != 3 && v.type != 4) {
          var arr = v.conditions.split(",");
          for (var m of arr) {
            if (m == "") {
              v.ischild = true;
              isSubmit++;
              break;
            }
          }
        }
        if (v.type == 4 && v.conditions.length == 0) {
          v.ischild = true;
          isSubmit++;
        }
      }
      if (isSubmit > 0) {
        return;
      }
      this.isbtn = true;
      var that = this;
      //初次请求hId设置为空
      window.localStorage['hId'] = "";
      that.data.hId = "";
      //设置不过滤
      that.data.isDistinct = 0;

      //提交请求
      var string = JSON.stringify(that.data);
      that.conditionData = JSON.parse(string);
      for (var v of that.conditionData.queryField) {
        if (v.type == 4) {
          var str = v.conditions.toString();
          str = "[" + str + "]";
          v.conditions = str;
          v.fieldLogic = "1";
        }
      }
      that
        .axios({
          method: "post",
          url: that.host + "historyStrategy/queryCompanyInfos",
          data: that.conditionData
        })
        .then(function(res) {
          that.isbtn = false;
          console.log(res.data.msg)
          that.resData = res.data;
          window.localStorage['hId'] = res.data.msg;
          if (that.resData.data.length >= that.resData.countSum) {
            that.lodText = "暂无更多";
          }
        })
        .catch(function(error) {
          that.isbtn = false;
        });
    },
    //筛选公司信息获取
    pushClueSubmit: function() {
      var isSubmit = 0;
      this.tiArr = [false, false, false];
      //字段间逻辑为空
      if (this.data.logicValue == "") {
        this.tiArr[0] = true;
        isSubmit++;
      }
      //未添加字段
      if (this.data.queryField.length == 0) {
        this.tiArr[1] = true;
        isSubmit++;
      }
      if (this.data.strategyName == "") {
        this.tiArr[2] = true;
        isSubmit++;
      }
      for (var v of this.data.queryField) {
        v.ischild = false;
        if (
          (v.fieldLogic == "" || v.field == "") &&
          v.type != 4 &&
          v.type != 3
        ) {
          v.ischild = true;
          isSubmit++;
        } else if (v.type != 3 && v.type != 4) {
          var arr = v.conditions.split(",");
          for (var m of arr) {
            if (m == "") {
              v.ischild = true;
              isSubmit++;
              break;
            }
          }
        }
        if (v.type == 4 && v.conditions.length == 0) {
          v.ischild = true;
          isSubmit++;
        }
      }
      if (isSubmit > 0) {
        return;
      }
      this.isbtn = true;
      var that = this;
      //提交请求
      var string = JSON.stringify(that.data);
      that.conditionData = JSON.parse(string);
      for (var v of that.conditionData.queryField) {
        if (v.type == 4) {
          var str = v.conditions.toString();
          str = "[" + str + "]";
          v.conditions = str;
          v.fieldLogic = "1";
        }
      }
      that
        .axios({
          method: "post",
          url: that.host + "historyStrategy/queryCompanyInfos",
          data: that.conditionData
        })
        .then(function(res) {
          that.isbtn = false;
          console.log(res.data.msg)
          that.resData = res.data;
          window.localStorage['hId'] = res.data.msg;
          if (that.resData.data.length >= that.resData.countSum) {
            that.lodText = "暂无更多";
          }
        })
        .catch(function(error) {
          that.isbtn = false;
        });
    },
    //判断用户输入范围值是否查询内容为空
    isValue: function() {
      //遍历所有范围
      for (var v of this.data.queryField) {
        v.isFile = false;
        if (v.type == 2 && v.fieldLogic == 1 && v.conditions != "") {
          //初始化提示控制值
          var arr = v.conditions.split(",");
          var c = 0;
          for (var m of arr) {
            var obj = this.toStringisNumber(m);
            if (obj.logic == "=") {
              c++;
            }
          }
          //等于条件不能超过两个
          if (c >= 2) {
            v.isFile = true;
            continue;
          }
        }
      }
    },
    //变化范围间逻辑
    numberChange: function() {
      this.isValue();
    },
    //保存转字符串
    stringPush: function() {
      //将范围字符串转为数组
      var arr = this.data.queryField[this.isNumber.k].conditions.split(",");
      //判断条件，根据条件拼接字符串
      if (this.isNumber.logic != "and") {
        arr[this.isNumber.i] = this.isNumber.logic + this.isNumber.number;
      } else {
        arr[this.isNumber.i] =
          this.isNumber.number + this.isNumber.logic + this.isNumber.maxNumber;
      }
      //将数组转为字符串
      this.data.queryField[this.isNumber.k].conditions = arr.toString();
      this.isValue();
    },
    //保存添加
    preservation: function() {
      //判断用户是否输入
      if (
        this.isNumber.number == "" ||
        (this.isNumber.logic == "and" && this.isNumber.maxNumber == "")
      ) {
        this.isNumber.isti = true;
        this.isNumber.tiText = "提示：您还未输入条件";
        return;
      }
      //判断用户输入的是否为数字
      if (
        isNaN(Number(this.isNumber.number)) ||
        (this.isNumber.logic == "and" && isNaN(Number(this.isNumber.maxNumber)))
      ) {
        this.isNumber.isti = true;
        this.isNumber.tiText = "提示：范围值必须为数字";
        return;
      }
      //and下判断是否符合逻辑
      if (this.isNumber.logic == "and") {
        if (Number(this.isNumber.number) > Number(this.isNumber.maxNumber)) {
          this.isNumber.isti = true;
          this.isNumber.tiText = "提示：请输入正确的条件";
          return;
        }
      }
      this.stringPush();
      this.dialogVisible = false;
    },
    //字符串转数值
    toStringisNumber: function(str) {
      //初始化数值储存临时对象
      var obj = { logic: "", number: "", maxNumber: "" };
      //判断两字符条件
      if (str.search(/[><!][=>]/) != -1) {
        obj.logic = str.substr(0, 2);
        obj.number = str.substr(2);
        //判断一字符条件
      } else if (str.search(/[><=]/) != -1) {
        obj.logic = str.substr(0, 1);
        obj.number = str.substr(1);
        //判断and条件
      } else if (str.search(/and/) != -1) {
        obj.logic = "and";
        var nub = str.split("and");
        obj.number = nub[0];
        obj.maxNumber = nub[1];
      }
      return obj;
    },
    //数值添加弹窗
    insertNumber: function(k, i, $event) {
      if ((k, i, $event.target.localName == "input")) {
        var str = this.data.queryField[k].conditions.split(",")[i];
        var obj = this.toStringisNumber(str);
        //赋值当前点击值
        this.isNumber = {
          k: "",
          i: "",
          unit: "",
          logic: "",
          number: "",
          maxNumber: "",
          isti: false,
          tiText: ""
        };
        this.isNumber.k = k;
        this.isNumber.i = i;
        this.isNumber.logic = obj.logic;
        this.isNumber.number = obj.number;
        this.isNumber.maxNumber = obj.maxNumber;
        this.isNumber.unit = this.data.queryField[k].unit;
        //打开弹窗
        this.dialogVisible = true;
      }
    },
    //关闭数值添加框
    handleClose: function() {
      this.dialogVisible = false;
    },
    //添加文本类型弹窗
    pushRange: function(k) {
      var that = this;
      //文本类型添加
      if (this.data.queryField[k].type == 1) {
        this.$prompt("请输入筛选词", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          inputPattern: /[^*]/,
          inputErrorMessage: "筛选词不能为空"
        })
          .then(({ value }) => {
            if (that.data.queryField[k].conditions != "") {
              that.data.queryField[k].conditions += "," + value;
            } else {
              that.data.queryField[k].conditions += value;
            }
            this.$message({
              type: "success",
              message: "已添加搜索词: " + value
            });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "取消输入"
            });
          });
        //数值类型添加
      } else if (this.data.queryField[k].type == 2) {
        that.data.queryField[k].conditions += ",";
      }
    },
    //删除字段范围值
    deleteTextItem: function(k, i) {
      //文本与数值范围删除
      //k当前字段index
      //i当前范围index
      var arr = this.data.queryField[k].conditions.split(",");
      arr.splice(i, 1);
      this.data.queryField[k].conditions = arr.toString();
      this.isValue();
    },
    //删除字段
    deleteField: function(k) {
      this.data.queryField.splice(k, 1);
      this.forField();
    },
    //遍历可选条件，为当前已选字段匹配范围类型值
    forField: function() {
      var arr = [];
      for (var v of this.data.queryField) {
        arr.push(v.field);
      }
      this.queryIsString = arr.join();
    },
    //字段变化处理
    change: function(k) {
      //重新选择字段，情况逻辑值与搜索范围
      this.data.queryField[k].fieldLogic = "1";
      this.data.queryField[k].conditions = "";
      for (var v of this.conditions) {
        if (v.field == this.data.queryField[k].field) {
          this.data.queryField[k].type = v.type;
          if (v.type == 2) {
            this.data.queryField[k].unit = v.unit;
          } else if (v.type == 4) {
            this.data.queryField[k].conditions = [];
          } else if (v.type == 3) {
            this.data.queryField[k].conditions = "1";
          }
          break;
        }
      }
      this.forField();
    },
    //添加字段
    pushQuery: function() {
      //判断当前已添加字段是否超出后端给出的字段
      if (this.conditions.length <= this.data.queryField.length) {
        this.$alert(
          "当前最多能添加" + this.conditions.length + "个字段",
          "温馨提示！",
          {
            confirmButtonText: "确定"
          }
        );
        return;
      }
      this.isPlac = true;
      this.data.queryField.push({
        //字段名
        field: "",
        //范围间逻辑关系
        fieldLogic: "1",
        //范围类型
        type: "",
        //范围值
        conditions: "",
        unit: ""
      });
    }
  },
  //渲染页面前请求数据
  created: function() {
    //加载地区信息
    this.provincesOptions = this.region;
    //加载导入信息
    var value = this.$route.params.value;
    if (typeof value == "object") {
      this.data.queryField = value.condition;
      this.data.logicValue = value.logicValue;
      this.data.strategyName = value.strategyName;
      this.forField();
    }

    //判断用户移动底部
    var that = this;
    window.onmousewheel = function() {
      if (that.$route.path.indexOf("screening") != -1 && !that.selectAll) {
        var htmlHeight = Number(
          window
            .getComputedStyle(document.documentElement)
            .height.replace("px", "")
        );
        if (document.body.scrollTop) {
          var scrollTop = document.body.scrollTop;
        } else {
          var scrollTop = document.documentElement.scrollTop;
        }
        var clientHeight = scrollTop + document.documentElement.clientHeight;
        if (htmlHeight == clientHeight) {
          var sum = Number(that.conditionData.pageNumber);
          if (
            Math.ceil(that.resData.countSum / 20) > sum &&
            that.islod == false
          ) {
            sum++;
            that.conditionData.pageNumber = sum;
            that.islod = true;
            that
              .axios({
                method: "post",
                url: that.host + "historyStrategy/queryCompanyInfos",
                data: that.conditionData
              })
              .then(function(res) {
                var arr = res.data.data;
                that.resData.data = that.resData.data.concat(arr);
                that.islod = false;
                if (that.resData.data.length >= that.resData.countSum) {
                  that.lodText = "暂无更多";
                }
              });
          }
        }
      }
    };
    //赋值id
    that.data.userId = window.localStorage["id"];
    that.seeEnterprise.userId = window.localStorage["id"];
    that.exportlist.userId = window.localStorage["id"];
    //获取筛选字段
    that
      .axios({
        method: "get",
        url: that.host + "field/getField"
      })
      .then(function(res) {
        that.conditions = res.data.data;
        //非导入页面设置初始字段值
        if (typeof value != "object") {
          var i = 0;
          for (var v of that.conditions) {
            if (i < 4) {
              that.data.queryField.push({
                //字段名
                field: v.field,
                //范围间逻辑关系
                fieldLogic: "1",
                //范围类型
                type: v.type,
                //范围值
                conditions: v.type == 3 ? "1" : "",
                unit: v.unit
              });
            }
            i++;
          }
        }
        that.forField();
        that.conditions.push({
          field: "地区",
          type: "4",
          unit: ""
        });
      });
  }
};
</script>

<style>
.row-btn {
  height: 34px;
  line-height: 34px;
}
.width {
  width: auto;
}
.unallocated-cue{
  margin-left: 15px;
}
.el-dialog__body {
  padding-bottom: 5px !important;
  padding-top: 10px !important;
}
.childApp {
  background: #fff;
  padding: 15px 15px 10px 15px;
  min-height: 650px;
}
.um-field-ti {
  position: absolute;
  bottom: -20px;
  left: 33%;
  width: 40%;
  height: 20px;
  line-height: 20px;
  background: none;
}
.field-re {
  position: relative;
}
.field-ti {
  position: absolute !important;
  bottom: -20px;
  left: 11.8%;
  font-size: 14px;
  width: 70%;
  height: 18px;
  line-height: 18px;
  background: none !important;
  /*color: #eb0000;*/
}
.w {
  background: none;
  width: 200px;
  float: left;
  height: 36px;
  line-height: 36px;
}
.push-row {
  height: 36px;
  line-height: 36px;
}
.top {
  margin-right: 10px;
}
.dialog-footer {
  text-align: center;
}
.scinput {
  width: auto !important;
}
.scinput > input {
  padding: 0 !important;
  text-align: center;
  cursor: pointer;
}
.el-input-group__append {
  width: 20px !important;
  padding: 0 4px;
  text-align: center;
}
.delect-close {
  transition: 0.5s;
}
.is-dq {
  text-align: left;
}
.nub {
  font-weight: 600;
  color: #409eff;
}
.strate {
  line-height: 32px;
  height: auto;
  margin-bottom: 30px;
  position: relative;
}
.input {
  width: 100%;
  overflow: hidden;
}
.x {
  color: #606266;
  font-weight: 600;
}
.delete-field {
  cursor: pointer;
  text-align: center;
  position: absolute;
  right: 18px;
  bottom: 2px;
}
.push-range {
  cursor: pointer;
  text-align: center;
}
.el-icon-circle-plus-outline {
  transform-origin: center center;
  transform: scale(1.5, 1.5);
  color: #757575;
}
.loc {
  transform-origin: center center;
  transform: scale(1.5, 1.5);
  color: #757575;
}
.row-height {
  height: 32px;
}
</style>
