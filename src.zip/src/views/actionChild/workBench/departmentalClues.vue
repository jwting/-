<template>
  <div>
    <div class="action_child work-app-style">
     <action_tit :title="radio=='queryCues'?'部门线索':'部门潜客'"></action_tit>
      <div class="search-margin">
        <el-menu :default-active="radio" class="el-menu-demo" mode="horizontal" @select="handleSelect">
          <el-menu-item index="queryCues">部门线索</el-menu-item>
          <el-menu-item index="querySubmersible">部门潜客</el-menu-item>
        </el-menu>
      </div>
      <screening-components :target="radio" @upload="pushData" :dept-id="depId()" :data="data"></screening-components>
    </div>
    <!--选择移动条数-->
    <el-dialog :visible.sync="isLookatThewHole" :center="true" width="400px">
      <div>
        <div v-if="isSelect">
          <div class="text-margin">
            <span>开始条数：&nbsp;&nbsp;</span>
            <el-input-number v-model="bars.min" style="margin-right: 30px"  :min="1" :max="radio=='queryCues'?departmentalData.countSum:departmentalSubmersi.countSum" label="开始条数"></el-input-number>
          </div>
          <div class="text-margin">
            <span>结束条数：&nbsp;&nbsp;</span>
            <el-input-number v-model="bars.max" :min="1" :max="radio=='queryCues'?departmentalData.countSum:departmentalSubmersi.countSum" label="结束条数"></el-input-number>
            <el-button style="margin-left: 10px" @click="bars.max=(radio=='queryCues'?departmentalData.countSum:departmentalSubmersi.countSum)" type="text">最大</el-button>
          </div>
        </div>
        <div>
          <span>跟进人：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <el-select v-if="!isyi" style="width: 120px" v-model="selectRep.deptId" placeholder="选择部门">
            <el-option
              v-for="item in departData"
              :key="item.id"
              :label="item.deptName"
              :value="item.id">
            </el-option>
          </el-select>
          <el-select v-if="isyi" style="width: 120px; " v-model="selectRep.destUserId" placeholder="选择员工">
            <el-option
              v-for="item in ClueData"
              :key="item.id"
              :label="item.nickName"
              :value="item.id">
            </el-option>
          </el-select>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button @click="isLookatThewHole = false">取 消</el-button>
          <el-button type="primary" @click="ThewHole">确 定</el-button>
        </span>
    </el-dialog>
    <div class="action_child">
      <div>
        <div class="text-margin float-left">
          <template v-if="myDepId==depId()">
            <el-button type="primary" :disabled="!selectRep.ids" @click="selectPubilk(true,false)">{{radio=="queryCues"?"分配选中":"移动选中"}}</el-button>
            <el-button type="primary" @click="selectPubilk(true,true)">{{radio=="queryCues"?"分配全部":"移动全部"}}</el-button>
            <el-button v-if="radio=='queryCues'" type="primary" :disabled="selectRep.ids==''"  @click="selectPubilk(false,false)">移动选中</el-button>
            <el-button v-if="radio=='queryCues'" type="primary" @click="selectPubilk(false,true)">移动全部</el-button>
          </template>
          <display-bars
            :msg="radio=='queryCues'?'条线索':'条潜客'"
            :count-sum="radio=='queryCues'?departmentalData.countSum:departmentalSubmersi.countSum">
          </display-bars>
        </div>
        <div class="float-right" v-if="radio=='queryCues'">
          <el-checkbox class="unallocated-cues" v-model="isSelectSearch" border>只查看未被加入服务的线索</el-checkbox>
        </div>
      </div>
      <el-table
        :data="departmentalData.data"
        key="454717"
        v-if="radio=='queryCues'"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">公司名</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                <div slot="reference"><span  class="color">{{scope.row.companyName}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="官网" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <a :href="scope.row.webSite.toString().indexOf('http')!=-1?scope.row.webSite:'http://'+scope.row.webSite" class="color" target="_blank">
                {{scope.row.webSite?scope.row.webSite:"/"}}
              </a>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="地址" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">地址</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.address}}</div>
                <div slot="reference"><span>{{scope.row.address}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="主营产品" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">主营产品</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.operation}}</div>
                <div slot="reference"><span>{{scope.row.operation}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="注册时间" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.createTime}}</span>
          </template>
        </el-table-column>
        <el-table-column label="部门" align="center">
          <template slot-scope="scope">
            <span>{{scope.row.deptName}}</span>
          </template>
        </el-table-column>
        <el-table-column label="跟进人" align="center">
          <template slot-scope="scope">
            <span v-if="scope.row.userName">{{scope.row.userName}}</span>
            <el-button @click="joinService(scope.row.id)" v-else type="text">加入服务</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-table
        v-else
        key="454617"
        :data="departmentalSubmersi.data"
        @selection-change="handleSelectionChange"
      >
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                  <div class="center pad font-popover">公司名</div>
                  <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                  <div slot="reference"><span class="color">{{scope.row.companyName}}</span></div>
                </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="意向类型" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.custType}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="跟进记录" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover
                placement="top"
                width="300"
                trigger="hover">
                <div class="center pad font-popover">地址</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.record}}</div>
                <div slot="reference"><span>{{scope.row.record}}</span></div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="上次跟进时间" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.lastDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="触达时间" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.firstDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="跟进人" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.userName}}</span>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <page-component
        :radio="radio"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :data="pageData">
      </page-component>
    </div>
  </div>
</template>

<script>
    import ScreeningComponents from "../publicComponent/screeningComponents";
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    import PageComponent from "../publicComponent/pageComponent";
    import DisplayBars from "../publicComponent/displayBars";
    export default {
      name: "departmentalClues",
      components: {DisplayBars, PageComponent,Action_tit,ScreeningComponents},
      data(){
        return{
          arr:[1515859200000,1519999900000],
          isSelectSearch:false,
          moveloding:false,
          isAdmin:window.localStorage['isadmin'],
          //分页与请求参数
          pageData:[
            {
              pageNumber:1,
              row:20,
              countSum:0,
              radio:"queryCues",
              queryVo:{
                deptId:this.depId(),
                userId:window.localStorage['id']
              }
            },
            {
              pageNumber:1,
              row:20,
              countSum:0,
              radio:"querySubmersible",
              custQueryVo:{
                deptId:this.depId(),
                userId:window.localStorage['id']
              }
            }
          ],
          dId:"",
          departId:"",
          nickId:"",
          isyi:"",
          ClueData:[],
          isSelect:"",
          bars:{
            max:"",
            min:""
          },
          isLookatThewHole:false,
          details:false,
          radio:"queryCues",
          data:{
            submersible:[
              {
                value: 'address',
                label: '地址'
              }, {
                value: 'operation',
                label: '行业'
              }, {
                value: 'companyName',
                label: '公司名'
              }
            ],
            clue:[
              {
                value: 'custType',
                label: '意向类型'
              },
              {
                value: 'companyName',
                label: '公司名'
              },
            ]
          },
          departData:[],
          departmentalSubmersi:{},
          departmentalData:{},
          selectRep:{
            ids:"",          //线索ID
            destUserId:"",	//用户ID
            deptId:"",
            userId:window.localStorage['id']
          },
          //根据筛选条n件分配线索
          allocateAll:{
            destUserId:"",
            queryVo:{
              deptId:this.depId(),
              userId:window.localStorage['id']
            }
          },
          //根据筛选条件分配潜客
          allocateAllClue:{
            destUserId:"",
            custQueryVo:{
              deptId:this.depId(),
              userId:window.localStorage['id']
            }
          },
        }
      },
      watch:{
        arr:{
          handler (cval, oval) {
            console.log(cval)
          },
          deep: true
        },
        //监听只查看未被分配
        isSelectSearch:function(){
          this.pageData[0].pageNumber = 1;
          this.isRadioGetData();
        },
        selectRep:{
          handler (cval, oval) {
            if(this.isyi){
              this.nubEmployee(false);
            }
          },
          deep: true
        },
        //监听线索
        departmentalData:{
          handler (cval, oval) {
            this.pageData[0].countSum = cval.countSum;
          },
          deep: true
        },
        //监听潜客
        departmentalSubmersi:{
          handler (cval, oval) {
            this.pageData[1].countSum = cval.countSum;
          },
          deep: true
        }
      },
      computed:{
        myDepId:function(){
          return window.localStorage['dId']
        },
      },
      methods:{
        depId:function(){
          const value = this.$route.query.value;
          if(value){
            var depId = value;
          }else {
            var depId = window.localStorage['dId'];
          }
          return depId
        },
        joinService:function(id){
          var data = {
            userId: window.localStorage['id'],
            ids:id
          };
          var url = this.host+"move/joinServer";
          this.msgDialog(url,data)
        },
        selectJoinService:function(){
          var data = {
            userId: window.localStorage['id'],
            ids:this.selectRep.ids
          };
          var url = this.host+"move/joinServer";
          this.msgDialog(url,data)
        },
        //打开分配与移动弹窗
        selectPubilk:function(is,sl){
          this.isSelect=sl;
          this.isyi=is;
          this.bars.max = this.radio=="queryCues"?this.departmentalData.countSum:this.departmentalSubmersi.countSum;
          if(!is){
            this.getDepartmentList();
          }else {
            this.nubEmployee();
          }
        },
        //获取部门列表
        getDepartmentList:function () {
          var that = this;
          this.axios({
            method: 'POST',
            data:{
              id:window.localStorage['cId']
            },
            url: this.host + "dept/searchDeptDeatil",
          }).then(function (res) {
            that.departData = res.data.data;
            that.isLookatThewHole=true;
          });
        },
        //选中
        handleSelectionChange:function(list){
          this.selectRep.ids = this.getUpdataId(list,"ids");
        },
        //组件数据
        pushData:function(data){
          var data = JSON.stringify(data);
          if(this.radio=="queryCues"){
            this.allocateAll.queryVo = JSON.parse(data);
            this.pageData[0].pageNumber = 1;
            this.pageData[0].queryVo = JSON.parse(data);
            this.isRadioGetData()
            console.log(this.pageData[0]);
          }else {
            this.allocateAllClue.custQueryVo = JSON.parse(data);
            this.pageData[1].pageNumber = 1;
            this.pageData[1].custQueryVo = JSON.parse(data);
            this.isRadioGetData()
          }
        },
        ThewHole:function(){
            if(this.radio=="queryCues"&&this.isyi&&!this.isSelect){
              var url = this.host+"move/moveDeptPoolToUser";
              var data = this.selectRep;
            }else if(this.radio=="queryCues"&&this.isyi&&this.isSelect){
              var url = this.host+"move/moveDeptPoolToUserByCondition";
              this.allocateAll.queryVo.startRow = this.bars.min;
              this.allocateAll.queryVo.endRow = (this.bars.max - this.bars.min)+1;
              this.allocateAll.destUserId = this.selectRep.destUserId;
              var data = this.allocateAll;
            }else if(this.radio=="queryCues"&&!this.isyi&&!this.isSelect){
              var url = this.host+"move/moveDeptPoolToDeptPool";
              var data = this.selectRep;
            }else if(this.radio=="queryCues"&&!this.isyi&&this.isSelect){
              var url = this.host+"move/moveDeptPoolByCondition";
              this.allocateAll.queryVo.startRow = this.bars.min;
              this.allocateAll.queryVo.endRow = (this.bars.max - this.bars.min)+1;
              this.allocateAll.destDeptId = this.selectRep.deptId;
              var data = this.allocateAll;
            }else if(this.radio!="queryCues"&&this.isyi&&!this.isSelect){
              var url = this.host+"custIntention/movePersonCustByIds";
              var data = this.selectRep;
              data.destDeptId = window.localStorage["dId"];
            }else if(this.radio!="queryCues"&&this.isyi&&this.isSelect){
              var url = this.host+"custIntention/movePersonCustByCondition";
              this.allocateAllClue.custQueryVo.startRow = this.bars.min;
              this.allocateAllClue.custQueryVo.endRow = (this.bars.max - this.bars.min)+1;
              this.allocateAllClue.destUserId = this.selectRep.destUserId;
              this.allocateAllClue.destDeptId = window.localStorage["dId"];
              var data = this.allocateAllClue;
            }
            this.moveloding = true;
            this.msgDialog(url,data);
        },
        //分配或移动ajax
        msgDialog:function(url,data){
          this.axios({
            method:'POST',
            data:data,
            url: url,
          }).then(res=>{
            this.isLookatThewHole = false;
            this.moveloding = false;
            this.isRadioGetData(false);
            this.$message({
              message: res.data.msg,
              type: 'success'
            });
          })
        },
        goDetails:function(){
          this.$router.push({ name: 'company',params:{value:'0'}});
        },
        handleSelect:function(v){
          this.radio = v;
          this.isRadioGetData();
        },
        handleSizeChange:function () {
          this.isRadioGetData();
        },
        handleCurrentChange:function () {
          this.isRadioGetData();
        },
        //根据radio请求线索或潜客
        isRadioGetData:function (isMsg=true) {
          if(this.radio=="queryCues"){
            var url = this.isSelectSearch?this.host+"companyInfo/getDeptPoolNoServerByCondition":this.host+"companyInfo/getDeptPoolByCondition";
            this.getData(url,this.pageData[0],"departmentalData",isMsg);
          }else {
            var url = this.host+"custIntention/getCustomersByDeptId";
            this.getData(url,this.pageData[1],"departmentalSubmersi",isMsg)
          }
        },
        nubEmployee:function (is=true) {
          var that = this;
          that.axios({
            url:this.host+'user/searchDeptEmployee',
            method: 'post',
            data:{
              id:window.localStorage['dId']
            }
          }).then(function (res){
            if(is){that.isLookatThewHole=true}
            that.ClueData = res.data.data
          })
        }
      },
      mounted(){
        console.log(this.$refs)
      },
      created:function () {
        const radio = this.$route.query.radio;
        if(radio){
          this.radio = radio;
        }
        this.departId = this.myDepId;
        this.isRadioGetData();
      }
    }
</script>

<style scoped>
  .unallocated-cues{
    margin-left: 10px;
    margin-top: 3px
  }
</style>
