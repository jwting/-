<template>
  <div>
    <action_tit title="企业详情"></action_tit>
    <div class="action_child el-box">
     <div class="cm-text">
       <!--录入潜客-->
       <el-dialog :visible.sync="enterTheSubmersible" :center="true" width="500px">
         <div>
           <el-row style="margin-bottom: 15px">
             <el-col :span="7"><span>客户意向等级:</span></el-col>
             <el-col :span="17">
               <el-select style="width: 160px" v-model="submersibleData.custType" placeholder="请选择">
                 <el-option
                   v-for="item in Grade"
                   :key="item.value"
                   :label="item.label"
                   :value="item.value">
                 </el-option>
               </el-select>
             </el-col>
           </el-row>
           <el-row>
             <el-col :span="7"><span>跟进记录:</span></el-col>
             <el-col :span="17">
               <el-input type="textarea" class="textarea" v-model="submersibleData.record"></el-input>
             </el-col>
           </el-row>
         </div>
         <span slot="footer" class="dialog-footer">
          <el-button @click="enterTheSubmersible = false">取 消</el-button>
          <el-button type="primary" @click="joinRemarks">确 定</el-button>
        </span>
       </el-dialog>
       <div class="le-img"><div class="img"></div></div>
       <div class="ri-img">
         <h3 style="font-size: 21px;margin: 0;">{{detailsData.companyName}}&nbsp;&nbsp;&nbsp;<span class="blue se"><span style="font-size: 25px">{{detailsData.custType}}</span></span></h3>
         <div style="margin-top: 15px">
           <span class="text-tit">联系人：</span><span class="text-act blue">{{detailsData.contacts}}</span><span>&nbsp;&nbsp;</span>
           <span class="text-tit">联系方式：</span><span class="text-act blue">{{detailsData.phone}}</span><span>&nbsp;&nbsp;</span>
           <span class="text-tit">公司官网：</span><a href="#" class="blue">{{detailsData.website?detailsData.website:'/'}}</a><span>&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit">主营业务：</span><span class="text-act">{{detailsData.operation}}</span>
         </div>
         <div style="margin-top: 5px">
           <span class="text-tit">企业类型：</span><span class="text-act">{{detailsData.types}}</span><span>&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit">注册资金：</span><span class="text-act">{{detailsData.money+'万'}}</span><span>&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit">注册时间：</span><span class="text-act">{{detailsData.createTime}}</span><span>&nbsp;&nbsp;&nbsp;</span>
         </div>
         <div style="margin-top: 5px">
           <span class="text-tit">企业地址：</span><span class="text-act">{{detailsData.address}}</span>
         </div>
         <div style="margin-top: 15px;height: 50px;line-height: 50px;border-top:1px solid #EBEEF5">
           <span class="text-tit">跟进人：</span><span class="text-act">{{detailsData.userName?detailsData.userName:'/'}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit">部门：</span><span class="text-act">{{detailsData.deptName?detailsData.deptName:'/'}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit" v-show="detailsData.custType">最新意向：</span><span class="text-act">{{detailsData.custType}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
           <span class="text-tit" v-show="detailsData.recode">跟进记录：</span><span class="text-act">{{detailsData.recode}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
           <!--<span class="text-tit">上次跟进时间：</span><span class="text-act">{{detailsData.lastDate}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>-->
           <!--<span class="text-tit">触达时间：</span><span class="text-act">{{detailsData.firstDate}}</span><span>&nbsp;&nbsp;&nbsp;&nbsp;</span>-->
         </div>
       </div>
     </div>
    </div>
      <div class="action_child" style="padding-left: 20px;min-height: 400px">
        <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
          <el-tab-pane label="备注记录" name="备注记录">备注记录</el-tab-pane>
        </el-tabs>
        <el-table
          :data="detailsData.custInfo"
          style="width: 90%;margin-top: 15px"
          border
          v-if="activeName=='备注记录'"
          key="115544"
        >
          <el-table-column label="意向类型" align="center">
            <template slot-scope="scope">
              <el-button type="text">{{scope.row.custType}}</el-button>
            </template>
          </el-table-column>
          <el-table-column prop="record" align="center" label="跟进记录"></el-table-column>
          <el-table-column align="center" label="跟进时间">
            <template slot-scope="scope">
              <el-button type="text">{{scope.row.lastDate}}</el-button>
            </template>
          </el-table-column>
          <el-table-column align="center" label="触达时间">
            <template slot-scope="scope">
              <el-button type="text">{{scope.row.firstDate}}</el-button>
            </template>
          </el-table-column>
        </el-table>
        <div style="margin-top: 20px">
          <el-button type="primary" @click="enterTheSubmersible=true" icon="el-icon-plus">添加备注</el-button>
        </div>
      </div>
  </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
      name: "company",
      components: {Action_tit},
      data(){
        return{
          enterTheSubmersible:false,
          activeName:"备注记录",
          detailsData:{},
          submersibleData:{
            userId:window.localStorage['id'],		//员工ID
            companyId:"",
            custType:"A",  //评级
            record:""    //意见
          },
          //评级数据
          Grade:[
            {
              value: 'A',
              label: 'A:成单'
            }, {
              value: 'B',
              label: 'B:有兴趣'
            }, {
              value: 'C',
              label: 'C:暂无需求'
            }, {
              value: 'D',
              label: 'D:不感兴趣/挂电话'
            }, {
              value: 'E',
              label: 'E:接不通'
            }
          ],
        }
      },
      methods:{
        joinRemarks:function(){
          var url = this.host + 'custIntention/saveCustIntention';
          var data = this.submersibleData;
          this.msgDialog(url,data);
          this.enterTheSubmersible=false;
        },
        handleClick:function () {

        },
        msgDialog:function(url,data){
          var that = this;
          this.axios({
            method:'POST',
            data:data,
            url: url,
          }).then(function (res) {
            that.getDetails();
            that.$message({
              message: res.data.msg,
              type: 'success'
            });
          });
        },
        getDetails:function () {
          var companyId = this.$route.params.value;
          this.submersibleData.companyId = companyId;
          var that = this;
          this.axios({
            method:'get',
            url:this.host + 'companyInfo/getCompanyById?companyId=' + companyId + '&userId='+window.localStorage['id'],
          }).then(function (res) {
            that.detailsData = res.data.data;
          })
        }
      },
      created:function () {
        this.getDetails();
      }
    }
</script>

<style scoped>
  .el-box{
    padding-left: 40px;
    padding-top:2px;
    min-height: 200px;
    margin-bottom: 5px;
    padding-bottom: 10px
  }
  .se{
    font-size: 22px;
  }
  .text-act{
    margin-right: 10px;
    display: inline-block;
    color: #303133;
  }
  .text-tit{
    display: inline-block;
    color: #606266;
  }
  .cm-text{
    overflow: hidden;
    height: auto;
    margin-top: 20px;
  }
  .img{
    width: 180px;
    height: 106px;
    margin-top: 10px;
    background-image: url("https://svc.bybigdata.com/image/com.png");
    background-size: auto 106px;
    background-position: center left;
    background-repeat: no-repeat;
  }
  .le-img{
    width: 160px;
    float: left;
    height: 100%;
  }
  .ri-img{
    width: 1000px;
    float: left;
    height: 100%;
  }
</style>
