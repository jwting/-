<template>
  <div>
    <div class="action_child work-app-style">
      <action_tit :title="radio=='queryCues'?'公司线索':'公司潜客'"></action_tit>
      <div class="search-margin">
        <el-menu
          :default-active="radio"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
        >
          <el-menu-item index="queryCues">公司线索</el-menu-item>
          <el-menu-item index="querySubmersible">公司潜客</el-menu-item>
        </el-menu>
      </div>
      <!--//条件字段-->
      <screening-components :data="data" :user-id="userId" :target="radio" @upload="pushData"></screening-components>
    </div>
    <!--选择移动条数-->
    <el-dialog :visible.sync="isLookatThewHole" :center="true" width="400px">
      <div>
        <div v-if="isSelect">
          <div class="text-margin">
            <span>开始条数：&nbsp;&nbsp;</span>
            <el-input-number
              v-model="bars.min"
              style="margin-right: 30px"
              :min="1"
              :max="radio=='queryCues'?clueData.countSum:clueSubmersi.countSum"
              label="开始条数"
            ></el-input-number>
          </div>
          <div class="text-margin">
            <span>结束条数：&nbsp;&nbsp;</span>
            <el-input-number
              v-model="bars.max"
              :min="1"
              :max="radio=='queryCues'?clueData.countSum:clueSubmersi.countSum"
              label="结束条数"
            ></el-input-number>
            <el-button
              style="margin-left: 10px"
              @click="bars.max=(radio=='queryCues'?clueData.countSum:clueSubmersi.countSum)"
              type="text"
            >最大</el-button>
          </div>
        </div>
        <div>
          <span>跟进人：&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
          <el-select style="width: 150px" v-model="departId" placeholder="选择部门">
            <el-option
              v-for="item in departData"
              :key="item.id"
              :label="item.deptName"
              :value="item.id"
            ></el-option>
          </el-select>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="isLookatThewHole = false">取 消</el-button>
        <el-button type="primary" :loading="moveloding" @click="ThewHole">确 定</el-button>
      </span>
    </el-dialog>
    <div class="action_child">
      <div style="overflow: hidden">
        <div class="text-margin float-left">
          <el-button
            type="primary"
            :disabled="this.list.length==0"
            @click="getDepartmentList(false)"
          >分配选中</el-button>
          <el-button type="primary" @click="getDepartmentList(true)">分配全部</el-button>
          <display-bars
            :msg="radio=='queryCues'?'条线索':'条潜客'"
            :count-sum="radio=='queryCues'?clueData.countSum:clueSubmersi.countSum"
          ></display-bars>
        </div>
        <div v-if="radio=='queryCues'" class="float-right">
          <el-checkbox class="unallocated-cues" v-model="isSelectSearch" border>只查看未被分配的线索</el-checkbox>
        </div>
      </div>
      <el-table
        :data="clueData.data"
        @selection-change="handleSelectionChange"
        v-if="radio=='queryCues'"
      >
        <el-table-column type="selection" align="center" width="55"></el-table-column>
        <el-table-column prop="companyName" label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover placement="top" width="300" trigger="hover">
                <div class="center pad font-popover">公司名</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                <div slot="reference">
                  <span class="color">{{scope.row.companyName}}</span>
                </div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="官网">
          <template slot-scope="scope">
            <div class="el-table-height">
              <a
                :href="scope.row.webSite.toString().indexOf('http')!=-1?scope.row.webSite:'http://'+scope.row.webSite"
                class="color"
                target="_blank"
              >{{scope.row.webSite?scope.row.webSite:"/"}}</a>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="注册时间">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.createTime}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="地址">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover placement="top" width="300" trigger="hover">
                <div class="center pad font-popover">地址</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.address}}</div>
                <div slot="reference">
                  <span>{{scope.row.address}}</span>
                </div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="行业">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover placement="top" width="300" trigger="hover">
                <div class="center pad font-popover">行业</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.operation}}</div>
                <div slot="reference">
                  <span>{{scope.row.operation}}</span>
                </div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="是否被分配">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span :class="scope.row.isJoin?'danger':'blue'">{{scope.row.isJoin?'是':'否'}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="部门">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.deptName?scope.row.deptName:'/'}}</span>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <el-table :data="clueSubmersi.data" @selection-change="handleSelectionChange" v-else>
        <el-table-column type="selection" align="center" width="55"></el-table-column>
        <el-table-column prop="companyName" label="公司名" align="center">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover placement="top" width="300" trigger="hover">
                <div class="center pad font-popover">公司名</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.companyName}}</div>
                <div slot="reference">
                  <span class="color">{{scope.row.companyName}}</span>
                </div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="意向类型">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span class>{{scope.row.custType}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="跟进备注">
          <template slot-scope="scope">
            <div class="el-table-height">
              <el-popover placement="top" width="300" trigger="hover">
                <div class="center pad font-popover">跟进备注</div>
                <div class="center pad" style="margin-bottom: 6px">{{scope.row.record}}</div>
                <div slot="reference">
                  <span>{{scope.row.record}}</span>
                </div>
              </el-popover>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="触达时间">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.firstDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="上次跟进时间">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.lastDate}}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column align="center" label="跟进人">
          <template slot-scope="scope">
            <div class="el-table-height">
              <span>{{scope.row.userName}}</span>
            </div>
          </template>
        </el-table-column>
      </el-table>
      <page-component
        :radio="radio"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :data="pageData"
      ></page-component>
    </div>
  </div>
</template>

<script>
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import ScreeningComponents from "../publicComponent/screeningComponents";
import PageComponent from "../publicComponent/pageComponent";
import DisplayBars from "../publicComponent/displayBars";
export default {
  name: "companyClue",
  components: { DisplayBars, PageComponent, ScreeningComponents, Action_tit },
  data() {
    return {
      moveloding: false,
      //分页与请求参数
      pageData: [
        {
          pageNumber: 1,
          row: 20,
          countSum: 0,
          radio: "queryCues",
          queryVo: {
            userId: window.localStorage["id"] //用户id
          }
        },
        {
          pageNumber: 1,
          row: 20,
          countSum: 0,
          radio: "querySubmersible",
          custQueryVo: {
            userId: window.localStorage["id"]
          }
        }
      ],
      isSelectSearch: false,
      departId: "",
      nickId: "",
      isSelect: "",
      departData: [],
      activeName2: false,
      isLookatThewHole: false,
      radio: "queryCues",
      bars: {
        min: 1,
        max: 1
      },
      data: {
        submersible: [
          {
            value: "address",
            label: "地址"
          },
          {
            value: "operation",
            label: "行业"
          },
          {
            value: "companyName",
            label: "公司名"
          }
        ],
        clue: [
          {
            value: "custType",
            label: "意向类型"
          },
          {
            value: "companyName",
            label: "公司名"
          }
        ]
      },
      conditionsList: [{}],
      //潜客
      clueSubmersi: {
        countSum: 0
      },
      //线索
      clueData: {
        data: []
      },
      list: [],
      selectRep: {
        userId: window.localStorage["id"], //员工ID
        ids: "", //线索ID
        deptId: ""
      },
      //根据筛选条件分配线索
      allocateAll: {
        queryVo: {
          userId: window.localStorage["id"]
        }
      },
      //根据筛选条件分配潜客
      allocateAllClue: {
        custQueryVo: {
          userId: window.localStorage["id"]
        }
      }
    };
  },
  watch: {
    //监听只查看未被分配
    isSelectSearch: function() {
      this.pageData[0].pageNumber = 1;
      this.isRadioGetData();
    },
    //监听线索
    clueData: {
      handler(cval, oval) {
        this.pageData[0].countSum = cval.countSum;
      },
      deep: true
    },
    //监听潜客
    clueSubmersi: {
      handler(cval, oval) {
        this.pageData[1].countSum = cval.countSum;
      },
      deep: true
    }
  },
  computed: {
    userId: function() {
      return window.localStorage["id"];
    }
  },
  methods: {
    //获取部门列表
    getDepartmentList: function(val) {
      var that = this;
      that.isSelect = val;
      this.axios({
        method: "POST",
        data: {
          id: window.localStorage["cId"]
        },
        url: this.host + "dept/searchDeptDeatil"
      }).then(function(res) {
        that.departData = res.data.data;
        that.isLookatThewHole = true;
      });
    },
    handleSelectionChange: function(list) {
      this.list = list;
      this.selectRep.ids = this.getUpdataId(list, "ids");
    },
    //变化线索或潜客
    handleSelect: function(v) {
      this.radio = v;
      this.list = [];
      this.isRadioGetData();
    },
    handleClick: function() {},
    //分配或移动ajax
    msgDialog: function(url, data) {
      var that = this;
      this.axios({
        method: "POST",
        data: data,
        url: url
      })
        .then(res => {
          that.moveloding = false;
          that.isLookatThewHole = false;
          that.isRadioGetData(false);
          that.$message({
            message: res.data.msg,
            type: "success"
          });
        })
        .catch(() => {
          that.moveloding = false;
        });
    },
    //分配线索
    ThewHole: function() {
      this.moveloding = true;
      //分配选中线索
      if (!this.isSelect && this.departId && this.radio == "queryCues") {
        this.selectRep.deptId = this.departId;
        var data = this.selectRep;
        var url = this.host + "move/moveCompanyPoolToDeptPool";
        //分配全部线索
      } else if (this.departId && this.radio == "queryCues") {
        this.allocateAll.queryVo.startRow = this.bars.min;
        this.allocateAll.queryVo.endRow = this.bars.max - this.bars.min + 1;
        this.allocateAll.queryVo.deptId = this.departId;
        var data = this.allocateAll;
        var url = this.host + "move/moveAllCompanyInfoByCondition";
        //分配选中潜客
      } else if (!this.isSelect && this.departId) {
        this.selectRep.deptId = this.departId;
        var data = this.selectRep;
        var url = this.host + "custIntention/moveCustToDeptByIds";
        //分配全部潜客
      } else if (this.isSelect && this.departId) {
        this.allocateAllClue.custQueryVo.startRow = this.bars.min;
        this.allocateAllClue.custQueryVo.endRow =
          this.bars.max - this.bars.min + 1;
        this.allocateAllClue.custQueryVo.deptId = this.departId;
        var data = this.allocateAllClue;
        var url = this.host + "custIntention/moveAllCustToDeptByCondition";
      }
      this.msgDialog(url, data);
    },
    //组件数据
    pushData: function(data) {
      if (this.radio == "queryCues") {
        this.allocateAll.queryVo = data;
        this.pageData[0].pageNumber = 1;
        this.pageData[0].queryVo = data;
      } else {
        this.allocateAllClue.custQueryVo = data;
        this.pageData[1].pageNumber = 1;
        this.pageData[1].custQueryVo = data;
      }
      this.isRadioGetData();
    },
    handleSizeChange: function() {
      this.isRadioGetData();
    },
    handleCurrentChange: function() {
      this.isRadioGetData();
    },
    toSearch: function() {},
    //根据radio请求线索或潜客
    isRadioGetData: function(isMsg = true) {
      if (this.radio == "queryCues") {
        var url = this.isSelectSearch
          ? this.host + "companyInfo/getCompanyPoolJoinedByCondition"
          : this.host + "companyInfo/getCompanyPoolByCondition";
        this.getData(url, this.pageData[0], "clueData", isMsg);
      } else {
        var url = this.host + "custIntention/getCustomersByCompanyId";
        this.getData(url, this.pageData[1], "clueSubmersi", isMsg);
      }
    }
  },
  created: function() {
    this.isRadioGetData();
  }
};
</script>

<style>
.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 45%;
}
.unallocated-cues {
  margin-left: 10px;
  margin-top: 3px;
}
</style>
