<template>
    <div>
        <action_tit title="首页"></action_tit>
        <div class="action_child home-header">
            <!-- <div class="home-footer-tit"><i class="fa fa-bar-chart"></i>&nbsp;&nbsp;昨日概况</div> -->
            <div class="clue-list">
                <div class="clue-tit"><span>昨日：</span><span>{{state}}</span></div>
                <div class="clue-list-already-allocated">
                    <div>
                        <div class="clue-icon icon-1">
                           <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">总线索</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{homeData.dcby}}</span></p>
                            </div>
                             <p class="clue-list-number">{{homeData.dcfy}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-icon icon-2">
                           <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">已分配</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{homeData.cfbys}}</span></p>
                            </div>
                            <p class="clue-list-number">{{homeData.cfys}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-icon icon-3">
                           <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">未分配</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{homeData.cfbyns}}</span></p>
                            </div>
                            <p class="clue-list-number">{{homeData.cfyns}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-icon icon-4">
                           <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">已跟进</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{homeData.ccby}}</span></p>
                            </div>
                            <p class="clue-list-number">{{homeData.ccfy}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-icon icon-5">
                           <i class="fa fa-id-card-o" aria-hidden="true"></i>
                        </div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">未跟进</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{homeData.ccbyns}}</span></p>
                            </div>
                            <p class="clue-list-number">{{homeData.ccfyns}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clue-list">
                <div class="clue-tit"><span>昨日：</span><span>{{stateSneak}}</span></div>
                <div class="clue-list-already-allocated sneak">
                    <div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">A类潜客</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{sneakData.ccbyA}}</span></p>
                            </div>
                             <p class="clue-list-number">{{sneakData.ccfyA}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">B类潜客</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{sneakData.ccbyB}}</span></p>
                            </div>
                            <p class="clue-list-number">{{sneakData.ccfyB}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">C类潜客</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{sneakData.ccbyC}}</span></p>
                            </div>
                            <p class="clue-list-number">{{sneakData.ccfyC}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">D类潜客</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{sneakData.ccbyD}}</span></p>
                            </div>
                            <p class="clue-list-number">{{sneakData.ccfyD}}</p>
                        </div>
                    </div>
                    <div>
                        <div class="clue-text">
                            <div>
                                <p class="clue-list-text">E类潜客</p>
                                <p class="clue-list-on-number"><span>前日 </span><span>{{sneakData.ccbyE}}</span></p>
                            </div>
                            <p class="clue-list-number">{{sneakData.ccfyE}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="guest-list">

            </div>
        </div>
        <!-- 查看小程序对话框   -->
        <el-dialog
            :visible.sync="dialogVisible"
            width="600px">
            <div class="dialog-box">
                <img src="https://svc.bybigdata.com/image/gh_5e7aecbbbffc_1280.jpg">
            </div>
        </el-dialog>
        <!-- 常用功能   -->
        <div class="action_child home-footer">
            <div class="home-footer-tit"><i class="fa fa-align-justify"></i>&nbsp;&nbsp;常用功能</div>
            <div class="page-list">
                <div v-for="(v,i) in pageList" :key="i" @click="handlePage(v.path)">
                    <p class="page-list-icon" :class="v.icon"></p>
                    <div class="page-list-text">
                        <p>{{v.title}}</p>
                        <p>{{v.alt}}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="action_child home-footer">
            <div class="home-footer-tit">更多服务</div>
            <div class="page-list">
                <div v-for="(v,i) in moreList" :key="i" @click="handleMore(v.path)">
                    <p class="page-list-icon" :class="v.icon"></p>
                    <div class="page-list-text">
                        <p>{{v.title}}</p>
                        <p>{{v.alt}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</template>

<<script>
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import mixinData from "./mixinData.js";
export default {
        mixins:[mixinData],
        name:'home',
        components: {Action_tit},
        data(){
            return{
                dialogVisible:false,
                clueListAlreadyAllocated:[
                   {
                       title:"部门总线索"
                   }
                ],
            }
        },
        methods: {
            handlePage(path){
                this.$router.push({name:path})
            },
            handleMore(path){
                if(path==='smallProgram'){
                    this.dialogVisible = true
                }
            }
        },
        computed: {
            state(){
                var state = window.localStorage['state']
                if(state==0){
                    return '公司线索'
                }else if(state==1){
                    return '部门线索'
                }else{
                    return '个人线索'
                }
            },
            stateSneak(){
                var state = window.localStorage['state']
                if(state==0){
                    return '公司潜客'
                }else if(state==1){
                    return '部门潜客'
                }else{
                    return '个人潜客'
                }
            }
        },
        created() {
            var rep = {
                userId:window.localStorage['id'],
                state:window.localStorage['state']
            }
            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"move/getYesterdayProfile"
            }).then(res=>{
                this.homeData = res.data.data
            })

            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"custIntention/queryCustCount"
            }).then(res=>{
                this.sneakData = res.data.data
            })
        },
}
</script>

<style scoped>
    @import './iconfont.css';
    .clue-tit{
        height: 30px;
        line-height: 30px;
        color: #909399;
        padding-left: 10px
    }
    .home-header{
        padding-bottom: 5px;
        background: none;
        min-height: 100px;
        margin-bottom: 10px;
        padding: 0;
    }
    .clue-icon{
        width: 40px;
        align-self: center;
        height: 40px;
        line-height: 40px;
        margin-right: 15px;
        text-align: center;
        border-radius: 50%;
        color: #fff;
    }
    .clue-text{
        display: flex;
        flex-wrap: nowrap;
    }
    .icon-1{
        background: #796AEE ;
    }
    .icon-2{
        background: #ff7676;
    }
    .icon-3{
        background: #54e69d;
    }
    .icon-4{
        background: #ffc36d;
    }
    .icon-5{
        background: #909399;
    }
    .home-footer{
        min-height: 100px;
        padding-bottom: 10px;
        margin-bottom: 10px;
    }
    .clue-list-already-allocated{
        display: flex;
        justify-content: space-between;
        flex-wrap: nowrap;
        padding: 25px 10px;
        background: #fff
        /* border-bottom: 1px solid #F2F6FC; */
    }
    .clue-list-already-allocated>div{
        /* width: 250px; */
        width: 25%;
        padding:15px;
        padding-left: 20px;
        border-radius: 5px;
        display: flex;
        flex-wrap: nowrap;
        margin-left: 10px;
        border-right: 1px solid #eee;
        /* background: #F2F6FC; */
    }
     /* .clue-list-already-allocated>div:nth-of-type(4){
        visibility: hidden;
    } */
    .clue-list-already-allocated>div:last-child{
        border-right: none;
    }
    .clue-list-already-allocated>div:first-child{
        margin-left: 0;
    }
    .clue-list-text{
        font-size: 14px;
        color: #909399;
        margin-bottom: 5px;
    }
    .clue-list-number{
        height: 30px;
        line-height: 30px;
        font-size: 24px;
        font-weight: 600;
        /* color: #409EFF; */
        margin-left: 12px;
        color: #606266;
    }
     .clue-list-on-number>span{
        font-size: 12px;
        color: #909399;
    }
     .clue-list-not-allocated{
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        border-bottom: 1px solid #F2F6FC;
        margin-top: 15px;
     }
    .clue-list-not-allocated>div{
        width: 18%;
        border: 1px solid #F2F6FC;
        margin-right: 2%;
        padding:10px;
        margin-bottom: 15px;
        border-radius: 5px;
    }
     .clue-list-not-allocated>div:nth-of-type(5){
         margin-right: 0;
     }
    .page-list{
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }
    .page-list>div{
        width: 330px;
        height: 90px;
        margin-bottom: 30px;
        display: flex;
        padding: 10px;
        cursor: pointer;
        transition: .2s;
        background: #fafafa;
        border-radius: 4px;
        margin-right: 30px;
        align-self: center;
    }
    .page-list>div:hover{
        margin-top: -4px;
    }
    .home-footer-tit{
        background: #EBEEF5;
        color: #606266;
        height: 42px;
        line-height: 42px;
        padding-left: 15px;
        margin-bottom: 20px;
    }
    .page-list-icon{
        width: 70px;
        height: 70px;
        background: #409EFF;
        text-align: center;
        line-height: 70px;
        color: #fff;
        font-size: 40px;
        border-radius: 5px;
        margin-right: 15px;
    }
    .page-list-text{
        padding: 12px 0;
    }
    .page-list-text>p:nth-of-type(1){
        margin-bottom: 3px;
    }
    .page-list-text>p:nth-of-type(2){
        font-size: 12px;
        color: #909399;
    }
    .dialog-box{
        display: flex;
        justify-content: center;
        margin-bottom: 45px;
    }
    .dialog-box>img{
        width: 200px;
        height: 200px;
    }
    .sneak>div{
        border: none;
    }
    .sneak{
        margin-bottom: 15px;
        padding-top:15px;
        padding-bottom: 15px;
    }
    </style>
