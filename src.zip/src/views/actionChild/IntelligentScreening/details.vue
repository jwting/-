<template>
  <div class="action_child">
    <action_tit title="匹配详情"></action_tit>
    <el-dialog title="提示" :visible.sync="dialogSelect" width="35%">
      <span>{{selectDate}}</span>
      <span slot="footer" class="dialog-footer">
          <el-button @click="dialogSelect = false">取 消</el-button>
          <el-button type="primary" @click="getSelect">确 定</el-button>
        </span>
    </el-dialog>
    <el-row class="exprot" :gutter="15">
      <el-col :span="16"><span>百邑为您匹配出 </span><span class="red">{{resData.countSum}}</span><span> 条线索</span></el-col>
      <el-col :span="2">
        <el-button :disabled="selectAll!=''" :loading="selectAll=='查看选中'" @click="handleCommand(1)" class="btn" type="primary">
          查看选中
        </el-button>
      </el-col>
      <el-col :span="2">
        <el-button :disabled="selectAll!=''" :loading="selectAll=='导出选中'" @click="handleCommand(2)" class="btn" plain type="primary">
          导出选中
        </el-button>
      </el-col>
      <el-col :span="2">
        <el-button :disabled="selectAll!=''" :loading="selectAll=='查看全部'" @click="handleCommand(3)" class="btn" type="primary">
          查看全部
        </el-button>
      </el-col>
      <el-col :span="2">
        <el-button :disabled="selectAll!=''" :loading="selectAll=='导出全部'" @click="handleCommand(4)" class="btn" plain type="primary">
          导出全部
        </el-button>
      </el-col>
    </el-row>
    <el-row class="tit-row">
      <el-col :span="1" class="center"><el-checkbox @change="pubilkChange" v-model="checked"></el-checkbox></el-col>
      <el-col :span="5" class="left">企业名称</el-col>
      <el-col :span="4" class="center">官网</el-col>
      <el-col :span="5" class="center">地址</el-col>
      <el-col :span="6" class="center">主营产品</el-col>
      <el-col :span="3" class="right pad">匹配率</el-col>
    </el-row>

    <div v-if="selectAll" style="height: 80px;width:100%;text-align: center;padding-top: 20px;">
      <el-progress :text-inside="true" :stroke-width="12" :percentage="toSelectNumber"></el-progress>
      <div class="center" style="margin-top: 5px">
        <span :style="toSelectNumber<100?'':'color:#67C23A;'" :class="toSelectNumber<100?'el-icon-loading':'el-icon-success'"></span><span style="color: #8a8a8a">{{toSelectNumber==100?"&nbsp;&nbsp;加载成功":"&nbsp;&nbsp;加载中 请稍后"}}</span>
      </div>
    </div>

    <!--筛选结果列表-->
    <el-row v-for="v in resData.data" class="act-row">
      <el-col :span="1" class="center"><el-checkbox @change="reChange" v-model="v.is"></el-checkbox></el-col>
      <el-col style="cursor: pointer" :span="5" class="left color" >
        <el-popover
          placement="top"
          width="300"
          trigger="hover">
          <div style="font-weight: 600;margin-bottom: 6px" class="center pad">公司名称</div>
          <div class="center pad" style="margin-bottom: 6px">{{v.companyName}}</div>
          <div slot="reference"><span>{{v.companyName}}</span></div>
        </el-popover>
      </el-col>
      <el-col :span="4" class="center pad"><a :href="'http://'+v.network" class="color"   target="_blank">{{v.website?v.website:"/"}}</a></el-col>
      <el-col style="cursor: pointer" :span="5" class="center pad">
        <el-popover
          placement="top"
          width="300"
          trigger="hover">
          <div style="font-weight: 600;margin-bottom: 6px" class="center pad">地址</div>
          <div class="center pad" style="margin-bottom: 6px">{{v.address}}</div>
          <div slot="reference"><span>{{v.address?v.address:'&nbsp;'}}</span></div>
        </el-popover>
      </el-col>
      <el-col style="cursor: pointer" :span="6" class="center pad">
        <el-popover
          placement="top"
          width="300"
          trigger="hover">
          <div style="font-weight: 600;margin-bottom: 6px" class="center pad">主营产品</div>
          <div class="center pad" style="margin-bottom: 6px">{{v.products}}</div>
          <div slot="reference"><span>{{v.products?v.products:'&nbsp;'}}</span></div>
        </el-popover>
      </el-col>
      <el-col :span="3" class="right pad">{{v.suitability ? v.suitability:"/"}}</el-col>
    </el-row>
    <div v-show="resData.countSum" style="text-align: center;margin-top: 20px">
      <el-button :loading="islod" style="background: #fff;border: none;color: #7a7a7a">{{islod?"努力加载中":lodText}}</el-button>
    </div>
  </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
        name: "mdetails",
      components: {Action_tit},
      data(){
          return{
            toSelectNumberInterval:null,
            toSelectNumber:0,
            isSelectAll:false,
            lodText:"滑动滚轮查看更多",
            islod:false,
            checked:false,
            fileName:"",
            selectAll:'',
            dialogSelect:false,
            selectDate:{},
            repData:{
              rows:20,
              pageNumber:1,
              userId:"",
              mId:"",
              resultNumber:""
            },
            resData:{
              status:"-1",
              countSum:0,
              data:[
              ]
            },
            //查看联系方式上传的数据
            seeEnterprise:{
              lists:[], 	//公司ID集合  逗号分隔
              userId:"", 	//用户ID
              type:0,  //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
              isTrue:0,
            },
            //导出联系方式
            exportlist:{
              lists:[],
              userId:1,       //用户ID
              isTrue:0,//0：查看需要消耗积分  1：导出
              type:3
            }
          }
        },
        methods:{
          // 查看与导出联系方式
          getSelect:function(){
            var that = this;
            that.settoSelectNumberInterval();
            that.dialogSelect = false;
            if(that.command==1){
              that.seeEnterprise.isTrue = 1;
              that.selectAll = "查看选中";
              that.axios({
                method: 'post',
                url: that.host+'clue/showMatchPhone',
                data:that.seeEnterprise,
              }).then(function (res){
                if(res.data.status==200){
                  that.isRespons(res.data.status,false,res.data.data);
                  that.$message({
                    type: 'success',
                    message: res.data.msg
                  });
                }else {
                  that.$message.error(res.data.msg);
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(that.command==2){
              that.exportlist.isTrue = 1;
              that.selectAll = "导出选中";
              that.axios({
                method: 'post',
                url: that.host+'clue/exportSmartMatch',
                data:that.exportlist,
              }).then(function (res){
                if(res.data.status==200){
                  that.isRespons(res.data.status,false,res.data.data);
                  that.urlDownload(res.data.data.FileUrl);
                  that.$message({
                    type: 'success',
                    message: res.data.msg
                  });
                }else {
                  that.$message.error(res.data.msg);
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(that.command==4){
              that.selectAll = "导出全部";
              var ids = that.getUpdataId(that.resData.data,"ids");
              that.axios({
                method: 'post',
                url: that.host+'clue/exportAllSmartMatch',
                data: {
                  type:"3",
                  ids:ids,
                  userId:window.localStorage['id'],
                  mId:that.repData.mId,
                  isTrue: 1   //0：查看需要消耗积分  1：导出
                },
              }).then(function (res){
                if(res.data.status==200){
                  that.isRespons(res.data.status,false,res.data.data);
                  that.$message({
                    type: 'success',
                    message: res.data.msg
                  });
                }else {
                  that.$message.error(res.data.msg);
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(that.command==3){
              var ids = that.getUpdataId(that.resData.data,"ids");
              that.selectAll = "查看全部";
              that.axios({
                method: 'post',
                url: that.host+'clue/showMatchAllPhone',
                data: {
                  mId:that.repData.mId,
                  isTrue: 1,   //0：查看需要消耗积分  1：导出
                  ids: ids,   //公司ID集合  逗号分隔
                  type:0,     //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
                  userId:window.localStorage['id']
                },
              }).then(function (res){
                if(res.data.status==200){
                  that.isRespons(res.data.status,false,res.data.data);
                  that.$message({
                    type: 'success',
                    message: res.data.msg
                  });
                }else {
                  that.$message.error(res.data.msg);
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }
          },
          //接收请求参数后
          isRespons:function(status,is,data){
            var that = this;
            clearInterval(that.toSelectNumberInterval);
            if(status==200){
              var m = 0;
              that.toSelectNumberInterval = setInterval(function () {
                if(m==0){
                  var i = (100-that.toSelectNumber)/2;
                  var ber = that.toSelectNumber+i;
                  that.toSelectNumber=parseFloat(parseFloat(ber).toFixed(2));
                  m++;
                }else if(m==1){
                  that.toSelectNumber = 100;
                  m++;
                }else{
                  //判断是否为查看
                  if(is){
                    that.dialogSelect = true;
                  }else {
                    var i = 0;
                    for (const key in data){
                      for (var v of that.resData.data){
                        if(v.id==key){
                          i++;
                          v.contactPhone = data[key];
                          break;
                        }
                      }
                    }
                  }
                  that.selectAll = "";
                  that.toSelectNumber = 0;
                  clearInterval(that.toSelectNumberInterval);
                }
              },300);
            }else if(status==405&&!is){
              that.selectAll = "";
              that.toSelectNumber = 0;
              // that.$message.error("");
              that.$confirm('积分不足，请联系客服充值', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              }).then(() => {
              }).catch(() => {
              })
            }else {
              that.selectAll = "";
              that.toSelectNumber = 0;
              that.$message.error("请求错误");
            }
          },
          //进度条定时器
          settoSelectNumberInterval:function(){
            var that = this;
            //初始化进度条定时器
            that.toSelectNumber = 0;
            var t = 0;
            //设置定时器
            that.toSelectNumberInterval = setInterval(function () {
              var i = 0;
              if(that.toSelectNumber<=60){
                i = Math.random()/2;
              }else if(that.toSelectNumber>60&&that.toSelectNumber<=90){
                i = Math.random();
                i = i/10;
              }else if(that.toSelectNumber>90&&that.toSelectNumber<95){
                t++;
                if(t>20){
                  i = Math.random();
                  i = i/8;
                }
              }else if(that.toSelectNumber>95&&that.toSelectNumber<98.5){
                i = Math.random();
                i = i/20;
              }
              var num = that.toSelectNumber;
              num+=i;
              num = parseFloat(num.toFixed(2));
              if(num>=100){
                num = 100;
              }
              that.toSelectNumber=num;
            },500);
          },
          //查看积分消耗
          handleCommand:function(command){
            var that = this;
            that.command = command;
            //  加载定时器
            that.settoSelectNumberInterval();
            if(command==1){
              //获取lists
              that.seeEnterprise.lists = that.getUpdataId(that.resData.data,"lists");
              //判断用户是否选择
              if(this.seeEnterprise.lists.length==0){
                that.$message({
                  type: 'warning',
                  message: '请选择需查看企业',
                });
                return;
              }
              that.seeEnterprise.isTrue = 0;
              that.selectAll = "查看选中";
              that.axios({
                method: 'post',
                url: that.host+'clue/showMatchPhone',
                data:that.seeEnterprise,
              }).then(function (res){
                that.isRespons(res.data.status,true);
                that.selectDate = res.data.data.Consumption;
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(command==2){
              that.exportlist.lists = that.getUpdataId(that.resData.data,"lists");
              that.exportlist.isTrue = 0;
              if(that.exportlist.lists.length==0){
                that.$message({
                  type: 'warning',
                  message: '请选择需导出的企业',
                });
                return;
              }
              that.selectAll = "导出选中";
              that.axios({
                method: 'post',
                url: that.host+'clue/exportSmartMatch',
                data:that.exportlist,
              }).then(function (res){
                that.isRespons(res.data.status,true);
                if(res.data.status==200){
                  that.selectDate = res.data.data.Consumption;
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(command==4){
              var ids = that.getUpdataId(that.resData.data,"ids");
              that.selectAll = "导出全部";
              that.axios({
                method: 'post',
                url: that.host+'clue/exportAllSmartMatch',
                data: {
                  type:"3",
                  ids:ids,
                  userId:window.localStorage['id'],
                  mId:that.repData.mId,
                  isTrue: 0   //0：查看需要消耗积分  1：导出
                },
              }).then(function (res){
                that.isRespons(res.data.status,true);
                if(res.data.status==200){
                  that.selectDate = res.data.data.Consumption;
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }else if(command==3){
              //获取lists
              var ids = that.getUpdataId(that.resData.data,"ids");
              that.selectAll = "查看全部";
              that.axios({
                method: 'post',
                url: that.host+'clue/showMatchAllPhone',
                data: {
                  mId:that.repData.mId,
                  isTrue: 0,   //0：查看需要消耗积分  1：导出
                  ids: ids,   //公司ID集合  逗号分隔
                  type:0,     //积分消耗类型    	//0：筛选 1：智能 2：充值 3:导出
                  userId:window.localStorage['id']
                },
              }).then(function (res){
                that.isRespons(res.data.status,true);
                if(res.data.status==200){
                  that.selectDate = res.data.data.Consumption;
                }
              }).catch(function (error) {
                that.selectAll = "";
                that.isSelectAll = false;
                that.$message.error('请求错误');
              });
            }
          },
          //导出联系方式
          exportHandleCommand:function(){

          },
          //单选
          reChange:function(e){
           /* var index = "";
            for (var i = 0;i<this.seeEnterprise.length;i++){
              if(e==this.seeEnterprise[i]){
                index = i;
                break;
              }
            }
            if(index!=""||index===0){
              this.seeEnterprise.splice(index,1)
            }else {
              this.seeEnterprise.push(e);
            }*/
          },
          //全选
          pubilkChange:function(e){
           /* this.seeEnterprise = [];
            for (var v of this.resData.data){
              if(e){
                this.seeEnterprise.push(v.enterprise);
              }
              v.is = e;
            }
            console.log(this.seeEnterprise);*/
            for (var v of this.resData.data){
              v.is = e;
            }
          },
        },
        created:function () {
          var that = this;
          //路由传参
          var value = this.$route.params.value.split("&");
          var data = that.repData;
          data.userId = window.localStorage["id"];
          data.mId = value[0];//任务ID
          data.fileName = value[1];//文件名
          data.resultNumber = value[2];//线索
          that.seeEnterprise.userId = window.localStorage["id"];
          var url = 'clue/querySmartResult?pageNumber='+data.pageNumber+'&rows='+data.rows+'&mId='+data.mId+'&userId='+data.userId;
          that.axios({
            method: 'get',
            url: that.host+url,
          }).then(function(res){
              if(res.data.status == 200){
                that.resData.data = res.data.data;
                that.resData.countSum = res.data.countSum;
                if(that.resData.countSum < 20){
                    that.lodText="暂无更多";
                }
              }
          }),
          window.onmousewheel = function () {
            if (that.$route.path.indexOf("mdetails")!=-1) {
              var htmlHeight = Number(window.getComputedStyle(document.documentElement).height.replace('px', ''));
              var clientHeight = document.documentElement.scrollTop + document.documentElement.clientHeight;
              if (htmlHeight == clientHeight) {
                var pageNumber = Number(that.repData.pageNumber);
                if (Math.ceil((that.resData.countSum/20)>pageNumber&&that.islod==false)) {
                  that.islod = true;
                  pageNumber++;
                  data.pageNumber = pageNumber;
                  //发送请求
                  that.axios({
                      method:"get",
                      url :that.host+'clue/querySmartResult?pageNumber='+data.pageNumber+'&rows='+data.rows+'&mId='+data.mId+'&userId='+data.userId,
                  }).then(function(res){
                      if(res.data.status == 200){
                        that.islod=false
                        var arr = res.data.data;
                        that.resData.data=that.resData.data.concat(arr);
                        if(that.resData.data.length>=that.resData.countSum){
                          that.lodText = "暂无更多"
                        }
                      }
                  })
                }
              }
            }
          };
        }
    }
</script>

<style scoped>
  .pad{
    padding: 0 10px;
  }
</style>
