<template>
  <div class="action_child">
    <action_tit title="匹配结果"></action_tit>
    <el-row class="tit-row">
      <el-col :span="3"><div>日期</div></el-col>
      <el-col :span="6"><div class="center">文件名</div></el-col>
      <el-col :span="6"><div class="center">运行时长</div></el-col>
      <el-col :span="3"><div class="center">结果数</div></el-col>
      <el-col :span="6" class="right"><div>操作</div></el-col>
    </el-row>
    <el-row class="act-row" v-for="(v,index) in resData.data">
      <el-col :span="3"><div>{{timestampToTime(v.createTime)}}</div></el-col>
      <el-col :span="6"><div class="center">{{v.fileName}}</div></el-col>
      <el-col :span="6">
        <div class="center">
        {{v.status == 0?"正在匹配中":v.runTime+'s'}}<i :class="v.status == 0?'el-icon-loading':''"></i></div>
      </el-col>
      <el-col :span="3"><div class="center">{{v.resultNumber?v.resultNumber:"/"}}</div></el-col>
      <el-col :span="6" class="right">
        <div>
          <el-button type="danger" @click="delectStrategy(v.id,index)">删除或取消</el-button>
          <el-button type="primary" @click="selectStrategy(v.id,v.fileName,v.resultNumber)">查看结果</el-button>
        </div>
      </el-col>
    </el-row>
    <div>
      <el-pagination
        v-if="resData.countSum>10"
        style="text-align: right;margin-top: 20px"
        :background="true"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :page-sizes="[10, 20, 50, 100]"
        :page-size="20"
        :pager-count="7"
        layout="total, sizes, prev, pager, next, jumper"
        :total="resData.countSum">
      </el-pagination>
    </div>
  </div>
</template>

<script>
    import Action_tit from "../publicComponent/action_tit/action_tit.vue";
    export default {
        name: "Matching",
      components: {Action_tit},
      data(){
          return{
            repData:{
              rows:20,
              pageNumber:1,
              userId:""
            },
            resData:{
              status:"-1",
              countSum:200,
              data:[]
            }

          }
        },
      methods:{
        //用户改变每页显示条数
        handleSizeChange:function(e){
          this.repData.rows = e;
          this.getHistorcal();
        },
        //用户改变页数
        handleCurrentChange:function(e){
          this.repData.pageNumber = e;
          this.getHistorcal();
        },
        selectStrategy:function (value,fileName,resultNumber) {
          if(resultNumber >= 1){
            this.$router.push({ name: 'mdetails',params:{value:value+"&"+fileName+"&"+resultNumber}});
          }else if(resultNumber==null){
            this.$message.error("正在匹配中！");
          }else if(resultNumber===0){
            this.$message.error("无可查看数据，请上传合理样本！");
          }
        },
        quitStrategy:function(){

        },
        delectStrategy:function (id,index) {
          var that = this;
          this.$confirm('此操作将永久删除该策略, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.axios({
              method:"get",
              url:this.host+"clue/delMatch?id="+id,
            }).then(function(res){
              if(res.data.status == 200){
                that.$message({
                  type: 'success',
                  message: '删除成功!'
                });
                that.resData.data.splice(index,1);
              }else if(res.data.status == 400){
                that.$message.error("删除失败！");
              }
            })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
          });
        },
        getHistorcal:function() {
          var that = this;
          var data = that.repData;
          var url = 'clue/queryAllMatch?userId='+data.userId+'&pageNumber='+data.pageNumber+'&rows='+data.rows;
          that.axios({
            method: 'get',
            url: that.host + url,
          }).then(function (res) {
            that.resData = res.data;
          })
        },
      },
      created:function () {
        this.repData.userId = window.localStorage["id"];
        this.getHistorcal();
      }
    }
</script>

<style scoped>

</style>
