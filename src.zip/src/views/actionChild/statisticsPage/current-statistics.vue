<template>
    <div class="action_child current-page">
        <action_tit title="当前统计"></action_tit>
        <el-menu :default-active="radio" class="el-menu-demo" mode="horizontal" @select="handleClue">
            <el-menu-item index="queryCues">线索</el-menu-item>
            <el-menu-item index="querySubmersible">潜客</el-menu-item>
        </el-menu>
        <div v-show="radio=='querySubmersible'">
            <div class="submersible-box">
                <div class="compony-statistics">
                    <p><i class="fa fa-building" aria-hidden="true"></i>&nbsp;公司</p>
                    <ul>
                        <li class="countE">{{componySubmersible.countE}}</li>
                        <li class="countD">{{componySubmersible.countD}}</li>
                        <li class="countC">{{componySubmersible.countC}}</li>
                        <li class="countB">{{componySubmersible.countB}}</li>
                        <li class="countA">{{componySubmersible.countA}}</li>
                    </ul>
                    <span>总线索：{{componySubmersible.allCount}}</span>
                    <div class="number-statistics">
                        <span>{{parseInt(componySubmersible.countB)+parseInt(componySubmersible.countC)}}</span>
                    </div>
                </div>
                <div class="dep-statistics">
                    <p>
                        <i class="fa fa-sitemap" aria-hidden="true"></i>
                        &nbsp;部门：
                        <el-select class="dep-select" v-model="depValue" placeholder="请选择">
                            <el-option
                            v-for="item in depList"
                            :key="item.id"
                            :label="item.deptName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </p>
                    <ul>
                        <li class="countE">{{depSubmersible.countE}}</li>
                        <li class="countD">{{depSubmersible.countD}}</li>
                        <li class="countC">{{depSubmersible.countC}}</li>
                        <li class="countB">{{depSubmersible.countB}}</li>
                        <li class="countA">{{depSubmersible.countA}}</li>
                    </ul>
                    <span>总线索：{{depSubmersible.allCount}}</span>
                    <div class="number-statistics">
                        <span>{{parseInt(depSubmersible.countB)+parseInt(depSubmersible.countC)}}</span>
                    </div>
                </div>
                <div class="staff-statistics">
                    <p>
                        <i class="fa fa-user-circle-o" aria-hidden="true"></i>
                        &nbsp;员工：
                        <el-select class="dep-select" v-model="staffValue" placeholder="请选择">
                            <el-option
                            v-for="item in employeeList"
                            :key="item.id"
                            :label="item.nickName"
                            :value="item.id">
                            </el-option>
                        </el-select>
                    </p>
                    <ul>
                        <li class="countE">{{staffSubmersible.countE}}</li>
                        <li class="countD">{{staffSubmersible.countD}}</li>
                        <li class="countC">{{staffSubmersible.countC}}</li>
                        <li class="countB">{{staffSubmersible.countB}}</li>
                        <li class="countA">{{staffSubmersible.countA}}</li>
                    </ul>
                    <span>总线索：{{staffSubmersible.allCount}}</span>
                    <div class="number-statistics">
                        <span>{{parseInt(staffSubmersible.countB)+parseInt(staffSubmersible.countC)}}</span>
                    </div>
                </div>
            </div>
        </div>
        <div v-show="radio=='queryCues'">
            <div>
                <div class="current-title"><i class="fa fa-building" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;公司</div>
                <div class="current-table">
                    <div class="current-pie-chart-box">
                        <div class="current-compony-pie-chart"></div>
                    </div>
                    <div class="current-table-text">
                        <p class="current-table-text-title"><span>总线索：</span><span>{{this.companyClue.allCount}}</span></p>
                        <div class="current-table-text-box">
                            <div class="current-table-text-box-text">
                                <div class="current-table-clue">
                                    <p>已分配线索:</p>
                                    <p>{{this.companyClue.serverCount}}</p>
                                </div>
                                <div class="current-table-no-clue">
                                    <p>未分配线索:</p>
                                    <p>{{this.companyClue.noServerCount}}</p>
                                </div>
                            </div>
                            <div class="current-table-text-box-shape">
                                <p>{{parseInt(this.companyClue.serverCount/this.companyClue.allCount*100)+'%'}}</p>
                                <p>{{parseInt(this.companyClue.noServerCount/this.companyClue.allCount*100)+'%'}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="current-title"><i class="fa fa-sitemap" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;部门</div>
                <div class="current-table">
                    <div class="current-pie-chart-box">
                        <div class="current-dep-pie-chart"></div>
                    </div>
                    <div class="current-table-text">
                        <p class="current-table-text-title"><span>总线索：</span><span>{{depClue.allCount}}</span></p>
                        <div class="current-table-text-box">
                            <div class="current-table-text-box-text">
                                <div class="current-table-clue">
                                    <p>已分配线索:</p>
                                    <p>{{depClue.serverCount}}</p>
                                </div>
                                <div class="current-table-no-clue">
                                    <p>未分配线索:</p>
                                    <p>{{depClue.noServerCount}}</p>
                                </div>
                            </div>
                            <div class="current-table-text-box-shape">
                                <p>{{parseInt(depClue.serverCount/depClue.allCount*100)+'%'}}</p>
                                <p>{{parseInt(depClue.noServerCount/depClue.allCount*100)+'%'}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="current-title"><i class="fa fa-user-circle-o" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp;员工</div>
                <div class="current-table">
                    <div class="current-pie-chart-box">
                        <div class="current-staff-pie-chart"></div>
                    </div>
                    <div class="current-table-text">
                        <p class="current-table-text-title"><span>总线索：</span><span>{{companyClue.allCount}}</span></p>
                        <div class="current-table-text-box">
                            <div class="current-table-text-box-text">
                                <div class="current-table-clue">
                                    <p>已备注:</p>
                                    <p>{{this.staffClue.serverCount}}</p>
                                </div>
                                <div class="current-table-no-clue">
                                    <p>未联络:</p>
                                    <p>{{staffClue.noServerCount}}</p>
                                </div>
                            </div>
                            <div class="current-table-text-box-shape">
                                 <p>{{parseInt(staffClue.serverCount/staffClue.allCount*100)+'%'}}</p>
                                <p>{{parseInt(staffClue.noServerCount/staffClue.allCount*100)+'%'}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import echarts from "echarts";
import Action_tit from "../publicComponent/action_tit/action_tit.vue";
import mixinData from "./current-data.js";
import mixinMounted from "./current-mounted.js";
export default {
    mixins:[mixinData,mixinMounted],
    components: {Action_tit},
    name:'currentStatistics',
    data() {
        return {
            radio:'queryCues'
        }
    },
    watch:{
        depValue(){
            this.getEmployeeList()
            this.queryDeptCustCount(this.depValue)
        },
        staffValue(){
            this.queryUserCustCount(this.staffValue)
        }
    },
    computed:{
        isQueryCues(){
            return this.radio=='queryCues'?'潜客':'线索'
        }
    },
    methods:{
        handleClue(val){
            this.radio = val;
        },
    },
    created(){
        this.queryCompanyCount()

        this.queryDeptCount()

        this.queryUserCount()

        this.queryCompanyCustCount()

        this.getDepartmentList()

        this.queryUserCustCount(window.localStorage['id'])
    }
}
</script>

<style scoped>
    .current-page{
        padding-top: 5px;
    }
    .current-title{
        background: #EBEEF5;
        color: #606266;
        height: 42px;
        line-height: 42px;
        padding-left: 15px;
        margin-top: 10px;
    }
    .current-table{
        display: flex;
        flex-wrap: nowrap;
        margin-top: -60px;
        margin-bottom: 40px;
        justify-content: space-between;
    }
    .current-pie-chart-box{
        width: 700px;
    }
    .current-compony-pie-chart{
        width: 400px;
        height: 400px;
        margin: 0 auto;
    }
    .current-table-text{
        width: 650px;   
        padding-top: 110px;
    }
    .current-table-text-box{
        display: flex;
        flex-wrap: nowrap;
        justify-content: flex-start
    }
    .current-table-text-title{
        color: #606266;  
        margin-bottom: 20px;
    }
    .current-table-text-title>span:last-child{
        color: #409EFF;
        font-weight: 600;
        font-size: 18px;
    }
    .current-table-text-box-text{
        width: 240px;
    }
    .current-table-clue{

    }
    .current-table-text-box-text>div{
        height: 120px;
        flex-grow: 1
    }
    .current-table-text-box-text>div>p:first-child{
        color: #606266;
        margin-bottom: 15px;
    }
    .current-table-text-box-text>div>p:last-child{
        font-size: 18px;
        font-weight: 600;
        color: #409EFF;
    }
    .current-table-text-box-shape{
        width: 300px;
    }
    .current-table-text-box-shape>p{
        width: 100px;
        height: 100px;
        line-height: 96px;
        border: 2px solid #E4E7ED;
        margin-bottom: 20px;
        text-align: center;
        font-size: 35px;
        color: #409EFF;
        font-weight: 600;
        border-radius:50% 
    }
    .current-dep-pie-chart{
        width: 400px;
        height: 400px;
        margin: 0 auto;
    }
    .current-staff-pie-chart{
        width: 400px;
        height: 400px;
        margin: 0 auto;
    }
    .submersible-box{
        display: flex;
        flex-wrap: nowrap;
        justify-content: space-between;
        margin-top: 30px;
        padding: 0 20px;
        padding-right: 250px;
    }
    .submersible-box>div{
        width: 180px;
        text-align: center;
        position: relative;
    }
    .number-statistics{
        position: absolute;
        height: 123px;
        line-height: 123px;
        width: 100px;
        color: #409EFF;
        font-weight: 600;
        text-align: center;
        right: -105px;
        bottom: 107px;
        border-left: #909399 solid 1px; 
        padding-right: 40px;
    }
    .number-statistics>span{
        font-size: 18px;
    }
    .submersible-box>div>p{
        height: 32px;
        line-height: 32px;
        margin-bottom: 15px;
        text-align: left;
    }
    .submersible-box>div>ul{
        width: 100%;
        height: 300px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        margin-bottom: 35px;
    }
    .dep-select{
        width: 100px;
    }
    .submersible-box>div>ul>li{
        line-height: 60px;
        text-align: center;
        flex-grow: 1;
        margin-bottom: 3px;
        color: #606266;
    }
    .countE{
        background: #dbe7f8;
    }
    .countD{
        background: #dbe7f8;
    }
    .countC{
        background: #91c4f9;
    }
    .countB{
        background: #91c4f9;
    }
    .countA{
        background: #409EFF;
    }
</style>

