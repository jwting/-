import echarts from "echarts";
export default {
    mounted() {
        var myChart = echarts.init(document.getElementById('funnel'));
        myChart.setOption(this.funnelPoption);
    },
    methods: {
        //获取员工列表
        getEmployeeList:function () {
            var rep = {
                id:this.depValue
            }
            this.axios({
              method: 'POST',
              data:rep,
              url: this.host + "user/searchDeptEmployee",
            }).then(res=>{
                this.employeeList = res.data.data;
                this.staffValue = this.employeeList[0].id
            });
        },
        //获取部门列表
        getDepartmentList() {
            this.axios({
                method: 'POST',
                data:{
                    id:window.localStorage['cId']
                },
                url: this.host + "dept/searchDeptDeatil",
            }).then(res=>{
                this.depList = res.data.data;
            });
        },
        //获取当前默认时间  
        getCurrenTime(){
            var currentTime = new Date().getTime();
            var startTime = currentTime - 2592000000

            currentTime = this.getDate(currentTime)
            startTime = this.getDate(startTime)

            this.time = [startTime,currentTime]
        },
        //时间转换成2019-01-01
        getDate(time){
            time = new Date(time)
            var Month = (time.getMonth()+1)>=10?time.getMonth()+1:'0'+(time.getMonth()+1)
            var date = (time.getDate())>=10?time.getDate():'0'+(time.getDate())
            return time.getFullYear() +'-' + Month + '-' + date
        },
        //获取个人数据
        queryUserCustEffect(){
            var rep = {
                userId:this.staffValue?this.staffValue:window.localStorage['id'],
                startDate:this.time[0],
                endDate:this.time[1]
            }
            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"custIntention/queryUserCustEffect"
            }).then(res=>{
                this.staffData = res.data.data
            })
        },
        //获取部门数据
        queryDeptCustEffect(){
            var rep = {
                deptId:this.depValue,
                startDate:this.time[0],
                endDate:this.time[1],
                type:this.depType
            }
            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"custIntention/queryDeptCustEffect"
            }).then(res=>{
                this.depData = res.data.data

                this.depHistogramOption.xAxis.data = []
                this.depHistogramOption.series.data = []
                this.depData.userSituation.forEach(element => {
                    this.depHistogramOption.xAxis.data.push(element.userName);
                    this.depHistogramOption.series.data.push(element.userCount);
                });

                if(this.depHistogramOption.xAxis.data.length !== 0){
                    var depHistogram = echarts.init(document.getElementsByClassName('dep-histogram')[0]);
                    depHistogram.setOption(this.depHistogramOption);
                }
            })
        },
        //获取公司数据
        queryCustEffect(){
            var rep = {
                userId:window.localStorage['id'],
                startDate:this.time[0],
                endDate:this.time[1],
                type:this.comValue
            }
            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"custIntention/queryCustEffect"
            }).then(res=>{
                this.companyData = res.data.data

                //公司线索处理
                var countAProportion = this.companyData.custCount.allCount?parseInt(this.companyData.custCount.countA/this.companyData.custCount.allCount*100)+'%':0
                var countBProportion = this.companyData.custCount.allCount?parseInt(this.companyData.custCount.countB/this.companyData.custCount.allCount*100)+'%':0
                var countCProportion = this.companyData.custCount.allCount?parseInt(this.companyData.custCount.countC/this.companyData.custCount.allCount*100)+'%':0
                var countDProportion = this.companyData.custCount.allCount?parseInt(this.companyData.custCount.countD/this.companyData.custCount.allCount*100)+'%':0
                var countEProportion = this.companyData.custCount.allCount?parseInt(this.companyData.custCount.countE/this.companyData.custCount.allCount*100)+'%':0

                this.funnelText = [
                    {
                        orderForm:this.companyData.custCount.countA,
                        proportion:countAProportion,
                        type:"A:成单"
                    },
                    {
                        orderForm:this.companyData.custCount.countB,
                        proportion:countBProportion,
                        type:"B:有兴趣"
                    },
                    {
                        orderForm:this.companyData.custCount.countC,
                        proportion:countCProportion,
                        type:"C:暂无需求"
                    },
                    {
                        orderForm:this.companyData.custCount.countD,
                        proportion:countDProportion,
                        type:'D:没有兴趣'
                    },
                    {
                        orderForm:this.companyData.custCount.countE,
                        proportion:countEProportion,
                        type:'E:打不通电话'
                    }
                ]

                this.companyHistogramOption.xAxis.data = []
                this.companyHistogramOption.series.data = []
                this.companyData.deptSituation.forEach(element => {
                    this.companyHistogramOption.xAxis.data.push(element.deptName);
                    this.companyHistogramOption.series.data.push(element.deptCount);
                });

                var companyHistogram = echarts.init(document.getElementsByClassName('company-histogram')[0]);
                companyHistogram.setOption(this.companyHistogramOption);

            })
        }
    },
}
