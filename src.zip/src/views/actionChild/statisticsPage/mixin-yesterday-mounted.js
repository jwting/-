export default {
    methods: {
        queryDeptCustCountByDate(depValue){
            this.axios({
              method: 'get',
              url: this.host + "custIntention/queryDeptCustCountByDate?deptId="+depValue,
            }).then(res=>{
              this.depTableData = res.data.data;
            });
        },
        queryUserCustCountByDate(userId){
            this.axios({
                method: 'get',
                url: this.host + "custIntention/queryUserCustCountByDate?userId="+userId,
            }).then(res=>{
                this.staffTableData = res.data.data;
            });
        },
        //获取员工列表
        getEmployeeList(){
            var rep = {
                id:this.depValue
            }
            this.axios({
                method: 'POST',
                data:rep,
                url: this.host + "user/searchDeptEmployee",
            }).then(res=>{
                this.employeeList = res.data.data;
                this.staffValue = this.employeeList[0].id
            });
        },
        //获取部门列表
        getDepartmentList() {
            this.axios({
              method: 'POST',
              data:{
                id:window.localStorage['cId']
              },
              url: this.host + "dept/searchDeptDeatil",
            }).then(res=>{
              this.depList = res.data.data;
            });
        },
        queryComCustCountByDate(){
            this.axios({
                method:'get',
                url: this.host+"custIntention/queryComCustCountByDate?userId="+window.localStorage['id']
            }).then(res=>{
                this.companyData = res.data.data
                this.drawCanvas()
            })
        },
        //获取部门数据
        queryDeptCustEffect(){
            var rep = {
                deptId:window.localStorage['id'],
                startDate:this.time[0],
                endDate:this.time[1],
                type:this.depType
            }
            this.axios({
                method:'POST',
                data:rep,
                url: this.host+"custIntention/queryDeptCustEffect"
            }).then(res=>{
                this.depData = res.data.data

                this.depHistogramOption.xAxis.data = []
                this.depHistogramOption.series.data = []
                this.depData.userSituation.forEach(element => {
                    this.depHistogramOption.xAxis.data.push(element.userName);
                    this.depHistogramOption.series.data.push(element.userCount);
                });
                
                if(this.depHistogramOption.xAxis.data.length !== 0){
                    var depHistogram = echarts.init(document.getElementsByClassName('dep-histogram')[0]);
                    depHistogram.setOption(this.depHistogramOption);
                }
            })
        },
        drawCanvas(){
            var self = this
            const canvas =  document.getElementById('sneak-conversion')
            canvas.width = '400';
            canvas.height = '360';
            const context = canvas.getContext('2d');

            var max = '';

            Object.keys(this.companyData.yesCustCount).forEach(element => {
                if(element!=='allCount'){
                   max = this.companyData.yesCustCount[element]>max ? this.companyData.yesCustCount[element] : max
                   max = this.companyData.befYesCustCount[element]>max ? this.companyData.befYesCustCount[element] : max
                }
            })
            console.log(this.companyData.yesCustCount)
            Object.keys(this.companyData.yesCustCount).forEach(element => {
                if(element!=='allCount'){
                    var renderData = {}
                    renderData.begin = [50,300-parseInt(this.companyData.befYesCustCount[element]/max*300)+10]
                    renderData.beginNumber = this.companyData.befYesCustCount[element]

                    renderData.end = [275,300-parseInt(this.companyData.yesCustCount[element]/max*300)+10]
                    renderData.endNumber = this.companyData.yesCustCount[element]

                    renderData.description = this.keyName[element]
                    
                    self.drawLine(context,renderData)
                }       
            });
            
            context.font="12px Verdana";
            context.fillStyle='#000000';
            context.beginPath()
            context.fillText('前日潜客',20,332);
            context.fill()

            context.font="12px Verdana";
            context.fillStyle='#000000';
            context.beginPath()
            context.fillText('昨日潜客',285,332);
            context.fill()

            context.strokeStyle = '#E4E7ED'
            context.beginPath()
            context.moveTo(100,325)
            context.lineTo(245,325)
            context.stroke()
        },
        drawLine(context,data){
            context.font="12px Verdana";
            context.fillStyle='#409EFF';
            context.beginPath()
            context.fillText(data.beginNumber,10,data.begin[1]+5);
            context.fill()

            context.fillStyle = '#409EFF'
            context.beginPath()
            context.arc(data.begin[0],data.begin[1],4,0,2*Math.PI)
            context.fill()

            context.strokeStyle = '#409EFF'
            context.beginPath()
            context.moveTo(data.begin[0],data.begin[1])
            context.lineTo(data.end[0],data.end[1])
            context.stroke()

            context.beginPath()
            context.arc(data.end[0],data.end[1],4,0,2*Math.PI)
            context.fill()

            context.font="12px Verdana";
            context.fillStyle='#409EFF';
            context.beginPath()
            context.fillText(data.endNumber,285,data.end[1]+3);
            context.fill()

            context.font="12px Verdana";
            context.fillStyle='#000000';
            context.beginPath()
            context.fillText(data.description,325,data.end[1]+3);
            context.fill()
        }
    },
}