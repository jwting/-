export default {
    data() {
        return {
            keyName:{
                countA:'A:已成单',//昨天A类潜客数量
                countB:'B:有兴趣',//昨天B类潜客数量
                countC:'C:暂无需求',//昨天C类潜客数量
                countD:'D:没有兴趣',//昨天D类潜客数量
                countE:'E:打不通电话',//昨天E类潜客数量
            },
            depTableData:{
                "yesCustCount":{
                },
                "befYesCustCount":{
                },
            },
            staffTableData:{
                "yesCustCount":{
                },
                "befYesCustCount":{
                },
            },
            staffValue:"",
            employeeList:[],
            depValue:"",
            depList:[],
            companyData:{
                "allCount":{
                    
                },
                "yesCustCount":{
                    
                },
                "befYesCustCount":{
                    
                }
            },
            sneakConversion:{
                'A':{beginNumber:20,}
            }
        }
    },
}