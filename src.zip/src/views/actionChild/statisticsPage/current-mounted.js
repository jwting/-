import echarts from "echarts";
export default {
    mounted(){},
    methods: {
        //获取员工列表
        getEmployeeList:function () {
            var rep = {
                id:this.depValue
            }
            this.axios({
                method: 'POST',
                data:rep,
                url: this.host + "user/searchDeptEmployee",
            }).then(res=>{
                this.employeeList = res.data.data;
                this.staffValue = this.employeeList[0].id
            });
        },
        //获取部门列表
        getDepartmentList() {
            this.axios({
              method: 'POST',
              data:{
                id:window.localStorage['cId']
              },
              url: this.host + "dept/searchDeptDeatil",
            }).then(res=>{
              this.depList = res.data.data;
              this.depValue = parseInt(window.localStorage['dId'])
            });
        },
        //个人潜客
        queryUserCustCount(val){
            this.axios({
                method: 'get',
                url: this.host + "custIntention/queryUserCustCount?userId="+val,
            }).then(res=>{
                this.staffSubmersible = res.data.data
            });
        },
        //部门潜客
        queryDeptCustCount(val){
            this.axios({
                method: 'get',
                url: this.host + "custIntention/queryDeptCustCount?deptId="+val,
            }).then(res=>{
                this.depSubmersible = res.data.data
            });
        },
        //公司潜客
        queryCompanyCustCount(){
            this.axios({
                method: 'get',
                url: this.host + "custIntention/queryCompanyCustCount?userId="+window.localStorage['id'],
            }).then(res=>{
                this.componySubmersible = res.data.data
            });
        },
        selectData(resData){
            var arr = []
            arr.push({value:resData.serverCount,name:'已分配数量'}) 
            arr.push({value:resData.noServerCount,name:'未分配数量'}) 
            return arr
        },
        //获取公司线索
        queryCompanyCount(){
            this.axios({
                method: 'get',
                url: this.host + "move/queryCompanyCount?userId="+window.localStorage['id'],
            }).then(res=>{
                this.companyClue = res.data.data
                this.companyOption.series.data = this.selectData(res.data.data)
                var currentComponyPieChar = echarts.init(document.getElementsByClassName('current-compony-pie-chart')[0]);
                currentComponyPieChar.setOption(this.companyOption);
            });
        },
        //获取部门线索
        queryDeptCount(){
            this.axios({
                method: 'get',
                url: this.host + "move/queryDeptCount?deptId="+window.localStorage['dId'],
            }).then(res=>{
                this.depClue = res.data.data
                this.depOption.series.data = this.selectData(res.data.data)
                var currentDepPieChar = echarts.init(document.getElementsByClassName('current-dep-pie-chart')[0]);
                currentDepPieChar.setOption(this.depOption);
            });
        },
        //获取个人线索
        queryUserCount(){
            this.axios({
                method: 'get',
                url: this.host + "move/queryUserCount?userId="+window.localStorage['id'],
            }).then(res=>{
                this.staffClue = res.data.data
                this.staffOption.series.data = this.selectData(res.data.data)
                var currentStaffPieChar = echarts.init(document.getElementsByClassName('current-staff-pie-chart')[0]);
                currentStaffPieChar.setOption(this.staffOption);
            });
        }
    },
}