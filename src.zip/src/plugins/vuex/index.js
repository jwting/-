import Vue from 'vue'
import Vuex from "vuex";

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    user:{
      deptName:"",
      userName:"",
      integral:""
    },
    isScreeningKep:false
  },
  mutations: {
    setUser (state,payload) {
      state.user=payload;
    },
    setScreeningKep(state,val){
      state.isScreeningKep = val
    }
  }
});

export default store
