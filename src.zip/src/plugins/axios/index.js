import Vue from 'vue'
import qs from 'qs'
import axios from 'axios'
import VueAxios from 'vue-axios'
import router from "../router";

Vue.use(VueAxios, axios)

var codeKey = "Authorization";

var urlData = qs.parse(window.location.search.slice(1))
console.log(qs.parse(window.location.search.slice(1)))
if(urlData[codeKey]){
  window.localStorage['state'] = urlData.state;
  window.localStorage["id"] = urlData.user.id;
  window.localStorage["cId"] = urlData.user.cId;
  window.localStorage["dId"] = urlData.user.dId;
  window.localStorage[codeKey] = urlData[codeKey];
  router.push('action/0/home')
}
console.log(qs.parse(window.location.search.slice(1)))
Vue.prototype.codeKey = codeKey;
if(window.localStorage[codeKey]){
  axios.defaults.headers.common[codeKey] = window.localStorage[codeKey];
}

axios.interceptors.response.use(function (response) {
  if(response.data.status==200){
    return response;
  }else if(response.data.status==300){
    router.push({ name: 'login'});
    Vue.prototype.$message({
      type: 'warning',
      message:'登录过期或未登录，请重新登录'
    });
    return Promise.reject(response.data.msg);
  }else {
    Vue.prototype.$message.error(response.data.msg);
    return Promise.reject(response.data.msg);
  }
},function (error) {
  return Promise.reject(error);
});



