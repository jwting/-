<template>
  <div>
    <ul class="nav_box">
       <li v-for="(item,i) in navData" :key="i">
        <div @click="handleParentClick(item[props.lable])" class="nav-row">
          <span class="nav-row-text"><i :class="item.icon" class="icon-style" aria-hidden="true"></i>{{item[props.lable]}}</span>
          <span class="nav-row-icon" :class="{'selection-icon-style':isSelection==item[props.lable]}"><i class="icon iconfont icon-jiantou"></i></span>
        </div>
        <el-collapse-transition>
          <div class="nav_child" v-show="isSelection==item[props.lable]">
            <div
              :key="i"
              v-for="(val,i) in item.child"
              @click="handleChildClick(val[props.selection],val)"
               class="nav-row nav-child-row"
               :class="{'selection-style':isChildSelection==val[props.selection]}">
              <span class="nav-row-child-text" >{{val[props.lable]}}</span>
            </div>
          </div>
        </el-collapse-transition>
      </li>
    </ul>
  </div>
</template>

<script>
    export default {
        name: "navigation-bar",
        props:{
          navData:{
            type:Array,
          },
          currentSelection:null,
          props:{
            defaults(){
              return {
                lable:'text',
                children:'child',
                selection:'name'
              }
            }
          },
          autoOpen:{
            defaults:true
          }
        },
        data(){
          return{
            isSelection:'',
            isChildSelection:this.currentSelection,
            selectionStyle:""
          }
        },
        watch:{
          currentSelection(newData){
            this.isChildSelection = newData
            this.handleAutoOpen()
          }
        },
        methods:{
          handleParentClick(value){
            if( this.isSelection == value){
              this.isSelection = ""
            }else {
              this.isSelection = value
            }
          },
          handleChildClick(value,val){
            this.isChildSelection = value;
            this.$emit('onChangeClick',val)
          },
          handleAutoOpen(){
            for (var v of this.navData){
              for (var val of v[this.props.children]){
                if(val[this.props.selection]==this.currentSelection){
                  this.isSelection = v.text
                }
              }
            }
          }
        },
        created(){
          if(this.autoOpen){
            this.handleAutoOpen()
          }
        }
    }
</script>

<style scoped>
  @import "css/font-awesome-4.7.0/css/font-awesome.min.css";
  @import "css/iconfont.css";
  .nav_box{
    box-sizing: border-box;
    min-width: 150px;
    background: #464c5b;
  }
  .icon-style{
    width: 26px;
    text-align: left;
  }
  .selection-icon-style{
    transform: rotate(90deg);
  }
  .nav-row{
    color: #b8c7ce;
    width: 100%;
    height: 60px;
    line-height: 60px;
    cursor: pointer;
    padding: 0 15px 0 20px;
    background: #495060;
  }
  .nav-row:hover{
    color: #fff;
  }
  .nav-row-text{
    float: left;
  }
  .nav-row-icon{
    height: 100%;
    float: right;
    transition: .5s;
  }
  .nav-child-row{
    height: 55px;
    line-height: 55px;
    background: #363e4f;
    transition: 1s;
  }
  .nav-row-child-text{
    display: block;
    padding-left: 20px;
    text-align: left;
  }
  .selection-style{
    background: #2d8cf0;
    color: #ffffff;
  }
</style>
