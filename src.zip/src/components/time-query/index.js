import timeQuery from './src/time-query'

export default function (Vue) {
  Vue.component(timeQuery.name,timeQuery)
}
